const require_config = require("../../config.js");
const require_test_logger = require("../test-logger.js");
//#region src/testing/fixtures/algokit-log-capture-fixture.ts
/**
* Creates a test fixture for capturing AlgoKit logs.
*
* @example
* ```typescript
* const logs = algoKitLogCaptureFixture()
*
* beforeEach(logs.beforeEach)
* afterEach(logs.afterEach)
*
* test('My test', () => {
*     const capturedLogs = logs.testLogger.capturedLogs
* })
* ```
*
* @returns The fixture
*/
const algoKitLogCaptureFixture = () => {
	const originalLogger = require_config.Config.logger;
	let hybridLogger;
	return {
		get testLogger() {
			return hybridLogger;
		},
		beforeEach: () => {
			hybridLogger = new require_test_logger.TestLogger(originalLogger);
			require_config.Config.configure({ logger: hybridLogger });
		},
		afterEach: () => {
			require_config.Config.configure({ logger: originalLogger });
		}
	};
};
//#endregion
exports.algoKitLogCaptureFixture = algoKitLogCaptureFixture;

//# sourceMappingURL=algokit-log-capture-fixture.js.map