import algosdk, { Address } from 'algosdk';
import { AlgorandClient } from '../';
import { TransactionSignerAccount } from '../types/account';
import { GetTestAccountParams } from '../types/testing';
import Account = algosdk.Account;
import Algodv2 = algosdk.Algodv2;
import Kmd = algosdk.Kmd;
/**
 * @deprecated Use `getTestAccount(params, algorandClient)` instead. The `algorandClient` object can be created using `AlgorandClient.fromClients({ algod, kmd })`.
 *
 * Creates an ephemeral Algorand account for the purposes of testing.
 * Returns a newly created random test account that is funded from the dispenser
 * DO NOT USE THIS TO CREATE A MAINNET ACCOUNT!
 * Note: By default this will log the mnemonic of the account.
 * @param params The config for the test account to generate
 * @param algod An algod client
 * @param kmd A KMD client, if not specified then a default KMD client will be loaded from environment variables and if not found fallback to the default LocalNet KMD client
 * @returns The account, with private key loaded
 */
export declare function getTestAccount(params: GetTestAccountParams, algod: Algodv2, kmd?: Kmd): Promise<Address & Account & TransactionSignerAccount>;
/**
 * Creates an ephemeral Algorand account for the purposes of testing.
 * Returns a newly created random test account that is funded from the dispenser
 * DO NOT USE THIS TO CREATE A MAINNET ACCOUNT!
 * Note: By default this will log the mnemonic of the account.
 * @param params The config for the test account to generate
 * @param algorand An AlgorandClient client
 * @returns The account, with private key loaded
 */
export declare function getTestAccount(params: GetTestAccountParams, algorand: AlgorandClient): Promise<Address & Account & TransactionSignerAccount>;
