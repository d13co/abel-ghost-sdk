import { __exportAll } from "./_virtual/_rolldown/runtime.mjs";
import algosdk from "algosdk";
//#region src/indexer-lookup.ts
var indexer_lookup_exports = /* @__PURE__ */ __exportAll({
	executePaginatedRequest: () => executePaginatedRequest,
	lookupAccountByAddress: () => lookupAccountByAddress,
	lookupAccountCreatedApplicationByAddress: () => lookupAccountCreatedApplicationByAddress,
	lookupAssetHoldings: () => lookupAssetHoldings,
	lookupTransactionById: () => lookupTransactionById,
	searchTransactions: () => searchTransactions
});
const DEFAULT_INDEXER_MAX_API_RESOURCES_PER_ACCOUNT = 1e3;
/**
* @deprecated Use `indexer.lookupTransactionByID(transactionId).do()`.
* Looks up a transaction by ID using Indexer.
* @param transactionId The ID of the transaction to look up
* @param indexer An indexer client
* @returns The result of the look-up
*/
async function lookupTransactionById(transactionId, indexer) {
	return await indexer.lookupTransactionByID(transactionId).do();
}
/**
* @deprecated Use `indexer.lookupAccountByID(accountAddress).do()`.
* Looks up an account by address using Indexer.
* @param accountAddress The address of the account to look up
* @param indexer An indexer client
* @returns The result of the look-up
*/
async function lookupAccountByAddress(accountAddress, indexer) {
	return await indexer.lookupAccountByID(accountAddress).do();
}
/**
* Looks up applications that were created by the given address; will automatically paginate through all data.
* @param indexer An indexer instance
* @param address The address of the creator to look up
* @param getAll Whether or not to include deleted applications
* @param paginationLimit The number of records to return per paginated request, default 1000
* @returns The list of application results
*/
async function lookupAccountCreatedApplicationByAddress(indexer, address, getAll = void 0, paginationLimit) {
	return await executePaginatedRequest((response) => {
		if ("message" in response) throw {
			status: 404,
			...response
		};
		return response.applications;
	}, (nextToken) => {
		let s = indexer.lookupAccountCreatedApplications(address).includeAll(getAll).limit(paginationLimit ?? DEFAULT_INDEXER_MAX_API_RESOURCES_PER_ACCOUNT);
		if (nextToken) s = s.nextToken(nextToken);
		return s;
	});
}
/**
* Looks up asset holdings for the given asset; will automatically paginate through all data.
* @param indexer An indexer instance
* @param assetId The ID of the asset to look up holdings for
* @param options Optional options to control the lookup
* @param paginationLimit The number of records to return per paginated request, default 1000
* @returns The list of application results
*/
async function lookupAssetHoldings(indexer, assetId, options, paginationLimit) {
	return await executePaginatedRequest((response) => {
		if ("message" in response) throw {
			status: 404,
			...response
		};
		return response.balances;
	}, (nextToken) => {
		let s = indexer.lookupAssetBalances(Number(assetId)).limit(paginationLimit ?? DEFAULT_INDEXER_MAX_API_RESOURCES_PER_ACCOUNT);
		if (options?.currencyGreaterThan !== void 0) s = s.currencyGreaterThan(options.currencyGreaterThan);
		if (options?.currencyLessThan !== void 0) s = s.currencyLessThan(options.currencyLessThan);
		if (options?.includeAll !== void 0) s = s.includeAll(options.includeAll);
		if (nextToken) s = s.nextToken(nextToken);
		return s;
	});
}
/**
* Allows transactions to be searched for the given criteria.
* @param indexer An indexer client
* @param searchCriteria The criteria to search for
* @param paginationLimit The number of records to return per paginated request, default 1000
* @returns The search results
*/
async function searchTransactions(indexer, searchCriteria, paginationLimit) {
	let currentRound = 0n;
	const transactions = await executePaginatedRequest((response) => {
		if ("message" in response) throw {
			status: 404,
			...response
		};
		if (response.currentRound > currentRound) currentRound = response.currentRound;
		return response.transactions;
	}, (nextToken) => {
		let s = searchCriteria(indexer.searchForTransactions()).limit(paginationLimit ?? DEFAULT_INDEXER_MAX_API_RESOURCES_PER_ACCOUNT);
		if (nextToken) s = s.nextToken(nextToken);
		return s;
	});
	return new algosdk.indexerModels.TransactionsResponse({
		currentRound,
		nextToken: void 0,
		transactions
	});
}
async function executePaginatedRequest(extractItems, buildRequest) {
	const results = [];
	let nextToken = void 0;
	while (true) {
		const response = await buildRequest(nextToken).do();
		const items = extractItems(response);
		if (items == null || items.length === 0) break;
		results.push(...items);
		nextToken = response["nextToken"];
		if (!nextToken) break;
	}
	return results;
}
//#endregion
export { executePaginatedRequest, indexer_lookup_exports, lookupAccountByAddress, lookupAccountCreatedApplicationByAddress, lookupAssetHoldings, lookupTransactionById, searchTransactions };

//# sourceMappingURL=indexer-lookup.mjs.map