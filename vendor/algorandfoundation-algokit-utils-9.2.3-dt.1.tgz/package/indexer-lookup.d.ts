import algosdk, { Address } from 'algosdk';
import { LookupAssetHoldingsOptions } from './types/indexer';
import Indexer = algosdk.Indexer;
export type SearchForTransactions = ReturnType<Indexer['searchForTransactions']>;
/**
 * @deprecated Use `indexer.lookupTransactionByID(transactionId).do()`.
 * Looks up a transaction by ID using Indexer.
 * @param transactionId The ID of the transaction to look up
 * @param indexer An indexer client
 * @returns The result of the look-up
 */
export declare function lookupTransactionById(transactionId: string, indexer: Indexer): Promise<algosdk.indexerModels.TransactionResponse>;
/**
 * @deprecated Use `indexer.lookupAccountByID(accountAddress).do()`.
 * Looks up an account by address using Indexer.
 * @param accountAddress The address of the account to look up
 * @param indexer An indexer client
 * @returns The result of the look-up
 */
export declare function lookupAccountByAddress(accountAddress: string | Address, indexer: Indexer): Promise<algosdk.indexerModels.AccountResponse>;
/**
 * Looks up applications that were created by the given address; will automatically paginate through all data.
 * @param indexer An indexer instance
 * @param address The address of the creator to look up
 * @param getAll Whether or not to include deleted applications
 * @param paginationLimit The number of records to return per paginated request, default 1000
 * @returns The list of application results
 */
export declare function lookupAccountCreatedApplicationByAddress(indexer: Indexer, address: string | Address, getAll?: boolean | undefined, paginationLimit?: number): Promise<algosdk.indexerModels.Application[]>;
/**
 * Looks up asset holdings for the given asset; will automatically paginate through all data.
 * @param indexer An indexer instance
 * @param assetId The ID of the asset to look up holdings for
 * @param options Optional options to control the lookup
 * @param paginationLimit The number of records to return per paginated request, default 1000
 * @returns The list of application results
 */
export declare function lookupAssetHoldings(indexer: Indexer, assetId: number | bigint, options?: LookupAssetHoldingsOptions, paginationLimit?: number): Promise<algosdk.indexerModels.MiniAssetHolding[]>;
/**
 * Allows transactions to be searched for the given criteria.
 * @param indexer An indexer client
 * @param searchCriteria The criteria to search for
 * @param paginationLimit The number of records to return per paginated request, default 1000
 * @returns The search results
 */
export declare function searchTransactions(indexer: Indexer, searchCriteria: (s: SearchForTransactions) => SearchForTransactions, paginationLimit?: number): Promise<algosdk.indexerModels.TransactionsResponse>;
export declare function executePaginatedRequest<TResult, TRequest extends {
    do: () => Promise<any>;
}>(extractItems: (response: any) => TResult[], buildRequest: (nextToken?: string) => TRequest): Promise<TResult[]>;
