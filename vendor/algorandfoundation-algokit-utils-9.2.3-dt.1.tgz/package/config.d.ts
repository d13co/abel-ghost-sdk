import { UpdatableConfig } from './types/config';
/** The AlgoKit config. To update it use the configure method. */
export declare const Config: UpdatableConfig;
