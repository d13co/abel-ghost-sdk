//#region src/config.ts
/** The AlgoKit config. To update it use the configure method. */
const Config = new (require("./types/config.js")).UpdatableConfig();
//#endregion
exports.Config = Config;

//# sourceMappingURL=config.js.map