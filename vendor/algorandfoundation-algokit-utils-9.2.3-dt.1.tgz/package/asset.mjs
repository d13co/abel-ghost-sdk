import { encodeTransactionNote, getSenderAddress } from "./transaction/transaction.mjs";
import { legacySendTransactionBridge } from "./transaction/legacy-bridge.mjs";
import { AlgorandClient } from "./types/algorand-client.mjs";
//#region src/asset.ts
/**
* @deprecated use `algorand.send.assetCreate()` / `algorand.createTransaction.assetCreate()` instead
*
* Create an Algorand Standard Asset (ASA).
* @param create The asset creation definition
* @param algod An algod client
* @returns The transaction object and optionally the confirmation if it was sent to the chain (`skipSending` is `false` or unset)
*
* @example Usage example
* ```typescript
* await algokit.createAsset({ creator: account, total: 1, decimals: 0, name: 'My asset' }, algod)
* ```
*/
async function createAsset(create, algod) {
	const params = {
		sender: getSenderAddress(create.creator),
		total: BigInt(create.total),
		decimals: create.decimals,
		assetName: create.name,
		unitName: create.unit,
		manager: create.manager ? getSenderAddress(create.manager) : void 0,
		clawback: create.clawbackAccount ? getSenderAddress(create.clawbackAccount) : void 0,
		freeze: create.freezeAccount ? getSenderAddress(create.freezeAccount) : void 0,
		reserve: create.reserveAccount ? getSenderAddress(create.reserveAccount) : void 0,
		defaultFrozen: create.frozenByDefault,
		lease: create.lease,
		metadataHash: create.metadataHash,
		note: encodeTransactionNote(create.note),
		url: create.url
	};
	return await legacySendTransactionBridge(algod, create.creator, create, params, (client) => client.assetCreate, (client) => client.assetCreate);
}
/**
* @deprecated use `algorand.send.assetOptIn()` / `algorand.createTransaction.assetOptIn()` instead
*
* Opt-in an account to an asset.
* @param optIn The opt-in definition
* @param algod An algod client
* @returns The transaction object and optionally the confirmation if it was sent to the chain (`skipSending` is `false` or unset)
*
* @example Usage example
* ```typescript
* await algokit.assetOptIn({ account, assetId }, algod)
* ```
*/
async function assetOptIn(optIn, algod) {
	const params = {
		assetId: BigInt(optIn.assetId),
		sender: getSenderAddress(optIn.account),
		note: encodeTransactionNote(optIn.note),
		lease: optIn.lease
	};
	return legacySendTransactionBridge(algod, optIn.account, optIn, params, (c) => c.assetOptIn, (c) => c.assetOptIn);
}
/**
* @deprecated use `algorand.send.assetOptOut()` / `algorand.createTransaction.assetOptOut()` instead
*
* Opt-out an account from an asset.
* @param optOut The opt-in definition
* @param algod An algod client
* @returns The transaction object and optionally the confirmation if it was sent to the chain (`skipSending` is `false` or unset)
*
* @example Usage example
* ```typescript
* await algokit.assetOptOut({ account, assetId, assetCreatorAddress }, algod)
* ```
*/
async function assetOptOut(optOut, algod) {
	const assetCreatorAddress = optOut.assetCreatorAddress ?? (await algod.getAssetByID(optOut.assetId).do()).params.creator;
	const params = {
		assetId: BigInt(optOut.assetId),
		creator: assetCreatorAddress,
		sender: getSenderAddress(optOut.account),
		note: encodeTransactionNote(optOut.note),
		lease: optOut.lease
	};
	return legacySendTransactionBridge(algod, optOut.account, optOut, params, (c) => c.assetOptOut, (c) => (params) => c.assetOptOut({
		...params,
		ensureZeroBalance: optOut.ensureZeroBalance ?? true
	}));
}
/**
* @deprecated use `algorand.asset.bulkOptIn()` instead
*
* Opt in to a list of assets on the Algorand blockchain.
*
* @param optIn - The bulk opt-in request.
* @param algod - An instance of the Algodv2 class from the `algosdk` library.
* @returns A record object where the keys are the asset IDs and the values are the corresponding transaction IDs for successful opt-ins.
* @throws If there is an error during the opt-in process.
* @example algokit.bulkOptIn({ account: account, assetIds: [12345, 67890] }, algod)
*/
async function assetBulkOptIn(optIn, algod) {
	const result = await AlgorandClient.fromClients({ algod }).setSignerFromAccount(optIn.account).asset.bulkOptIn(getSenderAddress(optIn.account), optIn.assetIds.map(BigInt), {
		note: encodeTransactionNote(optIn.note),
		maxFee: optIn.maxFee,
		suppressLog: optIn.suppressLog
	});
	const returnResult = {};
	for (const r of result) returnResult[Number(r.assetId)] = r.transactionId;
	return returnResult;
}
/**
* @deprecated use `algorand.asset.bulkOptOut()` instead
*
* Opt out of multiple assets in Algorand blockchain.
*
* @param optOut The bulk opt-out request.
* @param algod - An instance of the Algodv2 client used to interact with the Algorand blockchain.
* @returns A record object containing asset IDs as keys and their corresponding transaction IDs as values.
* @throws If there is an error during the opt-out process.
* @example algokit.bulkOptOut({ account: account, assetIds: [12345, 67890] }, algod)
*/
async function assetBulkOptOut(optOut, algod) {
	const result = await AlgorandClient.fromClients({ algod }).setSignerFromAccount(optOut.account).asset.bulkOptOut(getSenderAddress(optOut.account), optOut.assetIds.map(BigInt), {
		ensureZeroBalance: optOut.validateBalances ?? true,
		note: encodeTransactionNote(optOut.note),
		maxFee: optOut.maxFee,
		suppressLog: optOut.suppressLog
	});
	const returnResult = {};
	for (const r of result) returnResult[Number(r.assetId)] = r.transactionId;
	return returnResult;
}
//#endregion
export { assetBulkOptIn, assetBulkOptOut, assetOptIn, assetOptOut, createAsset };

//# sourceMappingURL=asset.mjs.map