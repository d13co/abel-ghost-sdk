const require_runtime = require("./_virtual/_rolldown/runtime.js");
const require_app = require("./types/app.js");
const require_transaction = require("./transaction/transaction.js");
const require_app_manager = require("./types/app-manager.js");
const require_composer = require("./types/composer.js");
const require_algorand_client_transaction_sender = require("./types/algorand-client-transaction-sender.js");
const require_asset_manager = require("./types/asset-manager.js");
const require_legacy_bridge = require("./transaction/legacy-bridge.js");
const require_app$1 = require("./app.js");
const require_app_deployer = require("./types/app-deployer.js");
let algosdk = require("algosdk");
algosdk = require_runtime.__toESM(algosdk);
//#region src/app-deploy.ts
/**
* @deprecated Use `algorand.appDeployer.deploy` instead.
*
* Idempotently deploy (create, update/delete if changed) an app against the given name via the given creator account, including deploy-time template placeholder substitutions.
*
* To understand the architecture decisions behind this functionality please see https://github.com/algorandfoundation/algokit-cli/blob/main/docs/src/content/docs/architecture-decisions/2023-01-12_smart-contract-deployment.md
*
* **Note:** When using the return from this function be sure to check `operationPerformed` to get access to various return properties like `transaction`, `confirmation` and `deleteResult`.
*
* **Note:** if there is a breaking state schema change to an existing app (and `onSchemaBreak` is set to `'replace'`) the existing app will be deleted and re-created.
*
* **Note:** if there is an update (different TEAL code) to an existing app (and `onUpdate` is set to `'replace'`) the existing app will be deleted and re-created.
* @param deployment The arguments to control the app deployment
* @param algod An algod client
* @param indexer An indexer client, needed if `existingDeployments` not passed in
* @returns The app reference of the new/existing app
*/
async function deployApp(deployment, algod, indexer) {
	const appManager = new require_app_manager.AppManager(algod);
	const newGroup = () => new require_composer.TransactionComposer({
		algod,
		getSigner: () => require_transaction.getSenderTransactionSigner(deployment.from),
		getSuggestedParams: async () => deployment.transactionParams ? { ...deployment.transactionParams } : await algod.getTransactionParams().do(),
		appManager
	});
	const deployer = new require_app_deployer.AppDeployer(appManager, new require_algorand_client_transaction_sender.AlgorandClientTransactionSender(newGroup, new require_asset_manager.AssetManager(algod, newGroup), appManager), indexer);
	const createParams = {
		approvalProgram: deployment.approvalProgram,
		clearStateProgram: deployment.clearStateProgram,
		sender: require_transaction.getSenderAddress(deployment.from),
		accountReferences: deployment.createArgs?.accounts?.map((a) => typeof a === "string" ? a : algosdk.default.encodeAddress(a.publicKey)),
		appReferences: deployment.createArgs?.apps?.map((a) => BigInt(a)),
		assetReferences: deployment.createArgs?.assets?.map((a) => BigInt(a)),
		boxReferences: deployment.createArgs?.boxes?.map(require_legacy_bridge._getBoxReference)?.map((r) => ({
			appId: BigInt(r.appIndex),
			name: r.name
		})),
		lease: deployment.createArgs?.lease,
		rekeyTo: deployment.createArgs?.rekeyTo ? require_transaction.getSenderAddress(deployment.createArgs?.rekeyTo) : void 0,
		staticFee: deployment.fee,
		maxFee: deployment.maxFee,
		extraProgramPages: deployment.schema.extraPages,
		onComplete: require_app$1.getAppOnCompleteAction(deployment.createOnCompleteAction),
		schema: deployment.schema
	};
	const updateParams = {
		approvalProgram: deployment.approvalProgram,
		clearStateProgram: deployment.clearStateProgram,
		sender: require_transaction.getSenderAddress(deployment.from),
		accountReferences: deployment.updateArgs?.accounts?.map((a) => typeof a === "string" ? a : algosdk.default.encodeAddress(a.publicKey)),
		appReferences: deployment.updateArgs?.apps?.map((a) => BigInt(a)),
		assetReferences: deployment.updateArgs?.assets?.map((a) => BigInt(a)),
		boxReferences: deployment.updateArgs?.boxes?.map(require_legacy_bridge._getBoxReference)?.map((r) => ({
			appId: BigInt(r.appIndex),
			name: r.name
		})),
		lease: deployment.updateArgs?.lease,
		rekeyTo: deployment.updateArgs?.rekeyTo ? require_transaction.getSenderAddress(deployment.updateArgs?.rekeyTo) : void 0,
		staticFee: deployment.fee,
		maxFee: deployment.maxFee,
		onComplete: algosdk.default.OnApplicationComplete.UpdateApplicationOC
	};
	const deleteParams = {
		sender: require_transaction.getSenderAddress(deployment.from),
		accountReferences: deployment.deleteArgs?.accounts?.map((a) => typeof a === "string" ? a : algosdk.default.encodeAddress(a.publicKey)),
		appReferences: deployment.deleteArgs?.apps?.map((a) => BigInt(a)),
		assetReferences: deployment.deleteArgs?.assets?.map((a) => BigInt(a)),
		boxReferences: deployment.deleteArgs?.boxes?.map(require_legacy_bridge._getBoxReference)?.map((r) => ({
			appId: BigInt(r.appIndex),
			name: r.name
		})),
		lease: deployment.deleteArgs?.lease,
		rekeyTo: deployment.deleteArgs?.rekeyTo ? require_transaction.getSenderAddress(deployment.deleteArgs?.rekeyTo) : void 0,
		staticFee: deployment.fee,
		maxFee: deployment.maxFee,
		onComplete: algosdk.default.OnApplicationComplete.DeleteApplicationOC
	};
	const encoder = new TextEncoder();
	const result = await deployer.deploy({
		createParams: deployment.createArgs?.method ? {
			...createParams,
			method: "txnCount" in deployment.createArgs.method ? deployment.createArgs.method : new algosdk.default.ABIMethod(deployment.createArgs.method),
			args: (await require_legacy_bridge._getAppArgsForABICall(deployment.createArgs, deployment.from)).methodArgs
		} : {
			...createParams,
			args: "appArgs" in (deployment?.createArgs ?? {}) ? deployment.createArgs?.appArgs?.map((a) => typeof a === "string" ? encoder.encode(a) : a) : void 0
		},
		updateParams: deployment.updateArgs?.method ? {
			...updateParams,
			method: "txnCount" in deployment.updateArgs.method ? deployment.updateArgs.method : new algosdk.default.ABIMethod(deployment.updateArgs.method),
			args: (await require_legacy_bridge._getAppArgsForABICall(deployment.updateArgs, deployment.from)).methodArgs
		} : {
			...updateParams,
			args: "appArgs" in (deployment?.updateArgs ?? {}) ? deployment.updateArgs?.appArgs?.map((a) => typeof a === "string" ? encoder.encode(a) : a) : void 0
		},
		deleteParams: deployment.deleteArgs?.method ? {
			...deleteParams,
			method: "txnCount" in deployment.deleteArgs.method ? deployment.deleteArgs.method : new algosdk.default.ABIMethod(deployment.deleteArgs.method),
			args: (await require_legacy_bridge._getAppArgsForABICall(deployment.deleteArgs, deployment.from)).methodArgs
		} : {
			...deleteParams,
			args: "appArgs" in (deployment?.deleteArgs ?? {}) ? deployment.deleteArgs?.appArgs?.map((a) => typeof a === "string" ? encoder.encode(a) : a) : void 0
		},
		metadata: deployment.metadata,
		deployTimeParams: deployment.deployTimeParams,
		onSchemaBreak: deployment.onSchemaBreak,
		onUpdate: deployment.onUpdate,
		existingDeployments: deployment.existingDeployments ? {
			creator: algosdk.Address.fromString(deployment.existingDeployments.creator),
			apps: Object.fromEntries(Object.entries(deployment.existingDeployments.apps).map(([name, app]) => [name, {
				...app,
				appAddress: algosdk.Address.fromString(app.appAddress),
				appId: BigInt(app.appId),
				createdRound: BigInt(app.createdRound),
				updatedRound: BigInt(app.updatedRound)
			}]))
		} : void 0,
		maxRoundsToWaitForConfirmation: deployment.maxRoundsToWaitForConfirmation,
		populateAppCallResources: deployment.populateAppCallResources,
		suppressLog: deployment.suppressLog
	});
	return {
		...result,
		appAddress: result.appAddress.toString(),
		appId: Number(result.appId),
		createdRound: Number(result.createdRound),
		updatedRound: Number(result.updatedRound)
	};
}
/**
* @deprecated Use `before.numByteSlice < after.numByteSlice || before.numUint < after.numUint` instead.
*
* Returns true is there is a breaking change in the application state schema from before to after.
*  i.e. if the schema becomes larger, since applications can't ask for more schema after creation.
*  Otherwise, there is no error, the app just doesn't store data in the extra schema :(
*
* @param before The existing schema
* @param after The new schema
* @returns Whether or not there is a breaking change
*/
function isSchemaIsBroken(before, after) {
	return before.numByteSlice < after.numByteSlice || before.numUint < after.numUint;
}
/**
* @deprecated Use `algorand.appDeployer.getCreatorAppsByName` instead.
*
* Returns a lookup of name => app metadata (id, address, ...metadata) for all apps created by the given account that have an `AppDeployNote` in the transaction note of the creation transaction.
*
* **Note:** It's recommended this is only called once and then stored since it's a somewhat expensive operation (multiple indexer calls).
*
* @param creatorAccount The account (with private key loaded) or string address of an account that is the creator of the apps you want to search for
* @param indexer An indexer client
* @returns A name-based lookup of the app information (id, address)
*/
async function getCreatorAppsByName(creatorAccount, indexer) {
	const lookup = await new require_app_deployer.AppDeployer(void 0, void 0, indexer).getCreatorAppsByName(require_transaction.getSenderAddress(creatorAccount));
	return {
		creator: lookup.creator.toString(),
		apps: Object.fromEntries(Object.entries(lookup.apps).map(([name, app]) => [name, {
			...app,
			appAddress: app.appAddress.toString(),
			appId: Number(app.appId),
			createdRound: Number(app.createdRound),
			updatedRound: Number(app.updatedRound)
		}]))
	};
}
/**
* @deprecated Use `{ dAppName: APP_DEPLOY_NOTE_DAPP, data: metadata, format: 'j' }` instead.
*
* Return the transaction note for an app deployment.
* @param metadata The metadata of the deployment
* @returns The transaction note as a utf-8 string
*/
function getAppDeploymentTransactionNote(metadata) {
	return {
		dAppName: require_app.APP_DEPLOY_NOTE_DAPP,
		data: metadata,
		format: "j"
	};
}
/**
* @deprecated Use `AppManager.replaceTealTemplateDeployTimeControlParams` instead
*
* Replaces deploy-time deployment control parameters within the given teal code.
*
* * `TMPL_UPDATABLE` for updatability / immutability control
* * `TMPL_DELETABLE` for deletability / permanence control
*
* Note: If these values are not undefined, but the corresponding `TMPL_*` value
*  isn't in the teal code it will throw an exception.
*
* @param tealCode The TEAL code to substitute
* @param params The deploy-time deployment control parameter value to replace
* @returns The replaced TEAL code
*/
function replaceDeployTimeControlParams(tealCode, params) {
	return require_app_manager.AppManager.replaceTealTemplateDeployTimeControlParams(tealCode, params);
}
/**
* @deprecated Use `AppManager.replaceTealTemplateParams` instead
*
* Performs template substitution of a teal file.
*
* Looks for `TMPL_{parameter}` for template replacements.
*
* @param tealCode The TEAL logic to compile
* @param templateParams Any parameters to replace in the .teal file before compiling
* @returns The TEAL code with replacements
*/
function performTemplateSubstitution(tealCode, templateParams) {
	return require_app_manager.AppManager.replaceTealTemplateParams(tealCode, templateParams);
}
/**
* @deprecated Use `algorand.appManager.compileTealTemplate` instead.
*
* Performs template substitution of a teal file and compiles it, returning the compiled result.
*
* Looks for `TMPL_{parameter}` for template replacements.
*
* @param tealCode The TEAL logic to compile
* @param algod An algod client
* @param templateParams Any parameters to replace in the .teal file before compiling
* @param deploymentMetadata The deployment metadata the app will be deployed with
* @returns The information about the compiled code
*/
async function performTemplateSubstitutionAndCompile(tealCode, algod, templateParams, deploymentMetadata) {
	tealCode = stripTealComments(tealCode);
	tealCode = performTemplateSubstitution(tealCode, templateParams);
	if (deploymentMetadata) tealCode = replaceDeployTimeControlParams(tealCode, deploymentMetadata);
	return await require_app$1.compileTeal(tealCode, algod);
}
/**
* @deprecated Use `AppManager.stripTealComments` instead.
*
* Remove comments from TEAL Code
*
* @param tealCode The TEAL logic to compile
* @returns The TEAL without comments
*/
function stripTealComments(tealCode) {
	return require_app_manager.AppManager.stripTealComments(tealCode);
}
//#endregion
exports.deployApp = deployApp;
exports.getAppDeploymentTransactionNote = getAppDeploymentTransactionNote;
exports.getCreatorAppsByName = getCreatorAppsByName;
exports.isSchemaIsBroken = isSchemaIsBroken;
exports.performTemplateSubstitution = performTemplateSubstitution;
exports.performTemplateSubstitutionAndCompile = performTemplateSubstitutionAndCompile;
exports.replaceDeployTimeControlParams = replaceDeployTimeControlParams;
exports.stripTealComments = stripTealComments;

//# sourceMappingURL=app-deploy.js.map