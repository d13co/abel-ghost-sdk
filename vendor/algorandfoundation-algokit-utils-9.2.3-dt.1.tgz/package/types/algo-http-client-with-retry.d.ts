import { BaseHTTPClientResponse, Query, URLTokenBaseHTTPClient } from 'algosdk/client';
/** A HTTP Client that wraps the Algorand SDK HTTP Client with retries */
export declare class AlgoHttpClientWithRetry extends URLTokenBaseHTTPClient {
    private static readonly MAX_TRIES;
    private static readonly MAX_BACKOFF_MS;
    private static readonly RETRY_STATUS_CODES;
    private static readonly RETRY_ERROR_CODES;
    private callWithRetry;
    get(relativePath: string, query?: Query<string>, requestHeaders?: Record<string, string>): Promise<BaseHTTPClientResponse>;
    post(relativePath: string, data: Uint8Array, query?: Query<string>, requestHeaders?: Record<string, string>): Promise<BaseHTTPClientResponse>;
    delete(relativePath: string, data: Uint8Array, query?: Query<string>, requestHeaders?: Record<string, string>): Promise<BaseHTTPClientResponse>;
}
