import { Config } from "../config.mjs";
import "./lifecycle-events.mjs";
import { DELETABLE_TEMPLATE_NAME, UPDATABLE_TEMPLATE_NAME } from "./app.mjs";
import { asJson, binaryStartsWith } from "../util.mjs";
import { encodeTransactionNote, getSenderAddress } from "../transaction/transaction.mjs";
import { getSimulateLimits } from "./dt-support.mjs";
import { legacySendTransactionBridge } from "../transaction/legacy-bridge.mjs";
import { callApp, compileTeal, createApp, getAppBoxNames, getAppBoxValue, getAppBoxValueFromABIType, getAppGlobalState, getAppLocalState, updateApp } from "../app.mjs";
import { deployApp, getCreatorAppsByName, performTemplateSubstitution, replaceDeployTimeControlParams } from "../app-deploy.mjs";
import { getABIDecodedValue, getABIEncodedValue, getABITupleFromABIStruct, getArc56Method, getArc56ReturnValue } from "./app-arc56.mjs";
import { arc32ToArc56 } from "./app-spec.mjs";
import { LogicError } from "./logic-error.mjs";
import algosdk, { Address } from "algosdk";
import { Buffer } from "buffer";
//#region src/types/app-client.ts
var ABIMethod = algosdk.ABIMethod;
var AtomicTransactionComposer = algosdk.AtomicTransactionComposer;
var getApplicationAddress = algosdk.getApplicationAddress;
var Indexer = algosdk.Indexer;
var OnApplicationComplete = algosdk.OnApplicationComplete;
var SourceMap = algosdk.ProgramSourceMap;
/** The maximum opcode budget for a simulate call as per https://github.com/algorand/go-algorand/blob/807b29a91c371d225e12b9287c5d56e9b33c4e4c/ledger/simulation/trace.go#L104 */
const MAX_SIMULATE_OPCODE_BUDGET = 32e4;
/** The algod clients whose simulate limits couldn't be read, so readonly calls don't ask again. */
const simulateLimitsFailed = /* @__PURE__ */ new WeakSet();
/**
* The extra opcode budget for a readonly call: the most the node allows, as a dtalgod reports it (more or less than
* stock), or the most stock algod allows. The limits are only asked for with the time-travel fork of algosdk; if that
* fails, the stock limit is used.
*/
async function readonlyOpcodeBudget(algod) {
	if (simulateLimitsFailed.has(algod)) return MAX_SIMULATE_OPCODE_BUDGET;
	try {
		const limits = await getSimulateLimits(algod);
		return limits?.reported ? limits.maxExtraOpcodeBudget : MAX_SIMULATE_OPCODE_BUDGET;
	} catch {
		simulateLimitsFailed.add(algod);
		return MAX_SIMULATE_OPCODE_BUDGET;
	}
}
/**
* Determines deploy time control (UPDATABLE, DELETABLE) value by inspecting application specification
* @param approval TEAL Approval program, not the base64 version found on the appSpec
* @param appSpec Application Specification
* @param templateVariableName Template variable
* @param callConfigKey Call config type
* @returns true if applicable call config is found, false if not found or undefined if variable not present
*/
function getDeployTimeControl(approval, appSpec, templateVariableName, callConfigKey) {
	if (!approval.includes(templateVariableName)) return void 0;
	const bareCallConfig = appSpec.bare_call_config[callConfigKey];
	if (!!bareCallConfig && bareCallConfig !== "NEVER") return true;
	return Object.values(appSpec.hints).some((h) => {
		const abiCallConfig = h.call_config[callConfigKey];
		return !!abiCallConfig && abiCallConfig !== "NEVER";
	});
}
const BYTE_CBLOCK = 38;
const INT_CBLOCK = 32;
/**
* Get the offset of the last constant block at the beginning of the program
* This value is used to calculate the program counter for an ARC56 program that has a pcOffsetMethod of "cblocks"
*
* @param program The program to parse
* @returns The PC value of the opcode after the last constant block
*/
function getConstantBlockOffset(program) {
	const bytes = [...program];
	const programSize = bytes.length;
	bytes.shift();
	/** The PC of the opcode after the bytecblock */
	let bytecblockOffset;
	/** The PC of the opcode after the intcblock */
	let intcblockOffset;
	while (bytes.length > 0) {
		/** The current byte from the beginning of the byte array */
		const byte = bytes.shift();
		if (byte === BYTE_CBLOCK || byte === INT_CBLOCK) {
			const isBytecblock = byte === BYTE_CBLOCK;
			/** The byte following the opcode is the number of values in the constant block */
			const valuesRemaining = bytes.shift();
			for (let i = 0; i < valuesRemaining; i++) if (isBytecblock) {
				/** The byte following the opcode is the length of the next element */
				const length = bytes.shift();
				bytes.splice(0, length);
			} else while ((bytes.shift() & 128) !== 0);
			if (isBytecblock) bytecblockOffset = programSize - bytes.length - 1;
			else intcblockOffset = programSize - bytes.length - 1;
			if (bytes[0] !== BYTE_CBLOCK && bytes[0] !== INT_CBLOCK) break;
		}
	}
	return Math.max(bytecblockOffset ?? 0, intcblockOffset ?? 0);
}
/** ARC-56/ARC-32 application client that allows you to manage calls and
* state for a specific deployed instance of an app (with a known app ID). */
var AppClient = class AppClient {
	_appId;
	_appAddress;
	_appName;
	_appSpec;
	_algorand;
	_defaultSender;
	_defaultSigner;
	_round;
	_approvalSourceMap;
	_clearSourceMap;
	_localStateMethods;
	_globalStateMethods;
	_boxStateMethods;
	_paramsMethods;
	_createTransactionsMethods;
	_sendMethods;
	_lastCompiled;
	/**
	* Create a new app client.
	* @param params The parameters to create the app client
	* @returns The `AppClient` instance
	* @example
	* ```typescript
	* const appClient = new AppClient({
	*   appId: 12345678n,
	*   appSpec: appSpec,
	*   algorand: AlgorandClient.mainNet(),
	* })
	*/
	constructor(params) {
		this._appId = params.appId;
		this._appAddress = algosdk.getApplicationAddress(this._appId);
		this._appSpec = AppClient.normaliseAppSpec(params.appSpec);
		this._appName = params.appName ?? this._appSpec.name;
		this._algorand = params.algorand;
		this._algorand.registerErrorTransformer(this.handleCallErrors);
		this._defaultSender = typeof params.defaultSender === "string" ? Address.fromString(params.defaultSender) : params.defaultSender;
		this._defaultSigner = params.defaultSigner;
		this._round = params.round === void 0 ? void 0 : BigInt(params.round);
		this._lastCompiled = {};
		this._approvalSourceMap = params.approvalSourceMap;
		this._clearSourceMap = params.clearSourceMap;
		this._localStateMethods = (address) => this.getStateMethods(() => this.getLocalState(address), () => this._appSpec.state.keys.local, () => this._appSpec.state.maps.local);
		this._globalStateMethods = this.getStateMethods(() => this.getGlobalState(), () => this._appSpec.state.keys.global, () => this._appSpec.state.maps.global);
		this._boxStateMethods = this.getBoxMethods();
		this._paramsMethods = {
			...this.getMethodCallParamsMethods(),
			/** Get parameters to define bare (raw) transactions to the current app */
			bare: this.getBareParamsMethods()
		};
		this._createTransactionsMethods = {
			...this.getMethodCallCreateTransactionMethods(),
			/** Get transactions for bare (raw) calls to the current app */
			bare: this.getBareCreateTransactionMethods()
		};
		this._sendMethods = {
			...this.guardPinnedSends(this.getMethodCallSendMethods(), ["call"]),
			/** Send bare (raw) transactions to the current app */
			bare: this.guardPinnedSends(this.getBareSendMethods(), [])
		};
	}
	/** Wraps send methods so that they throw on a client pinned to a round, except the `allowed` ones, which check themselves. */
	guardPinnedSends(methods, allowed) {
		const guarded = { ...methods };
		for (const [name, method] of Object.entries(methods)) {
			if (allowed.includes(name) || typeof method !== "function") continue;
			guarded[name] = (async (...args) => {
				this.assertNotPinned(`send ${String(name)}`);
				return await method(...args);
			});
		}
		return guarded;
	}
	assertNotPinned(action) {
		if (this._round !== void 0) throw new Error(`Can't ${action}: this app client is pinned to round ${this._round}, so it can only read state and make readonly calls`);
	}
	/** The round reads use: the one in `options`, else the round this client is pinned to, if any. */
	readOptions(options) {
		const round = options?.round ?? this._round;
		return round === void 0 ? void 0 : { round };
	}
	/**
	* The round this client is pinned to, if any (see `atRound`).
	*/
	get round() {
		return this._round;
	}
	/**
	* Returns a clone of this app client pinned to a past round (needs dtalgod time travel and the time-travel fork of
	* algosdk): state reads (`state.global|local|box`, `getGlobalState`, `getBoxValue`, ...) read the state as of the end
	* of that round, and readonly ABI calls are simulated at that round. The pinned client can't send transactions.
	*
	* Generated typed clients take an `AppClient`, so `new MyAppClient(myAppClient.appClient.atRound(round))` gives
	* typed state and readonly calls at that round.
	*
	* @param round The round to pin to, or `undefined` for a client that reads the latest state
	* @returns The pinned app client
	* @example
	* ```typescript
	* const past = appClient.atRound(45_000_000n)
	* const counter = await past.state.global.getValue('counter')
	* const result = await past.send.call({ method: 'get_counter' })
	* ```
	*/
	atRound(round) {
		return this.clone({ round });
	}
	/**
	* Clone this app client with different params
	*
	* @param params The params to use for the the cloned app client. Omit a param to keep the original value. Set a param to override the original value. Setting to undefined will clear the original value.
	* @returns A new app client with the altered params
	* @example
	* ```typescript
	* const appClient2 = appClient.clone({ defaultSender: 'NEW_SENDER_ADDRESS' })
	* ```
	*/
	clone(params) {
		return new AppClient({
			appId: this._appId,
			appSpec: this._appSpec,
			algorand: this._algorand,
			appName: this._appName,
			defaultSender: this._defaultSender,
			defaultSigner: this._defaultSigner,
			approvalSourceMap: this._approvalSourceMap,
			clearSourceMap: this._clearSourceMap,
			round: this._round,
			...params
		});
	}
	/**
	* Returns a new `AppClient` client, resolving the app by creator address and name
	* using AlgoKit app deployment semantics (i.e. looking for the app creation transaction note).
	* @param params The parameters to create the app client
	* @returns The `AppClient` instance
	* @example
	* ```typescript
	* const appClient = await AppClient.fromCreatorAndName({
	*   creatorAddress: 'CREATOR_ADDRESS',
	*   name: 'APP_NAME',
	*   appSpec: appSpec,
	*   algorand: AlgorandClient.mainNet(),
	* })
	*/
	static async fromCreatorAndName(params) {
		const appSpec = AppClient.normaliseAppSpec(params.appSpec);
		const appMetadata = (params.appLookupCache ?? await params.algorand.appDeployer.getCreatorAppsByName(params.creatorAddress, params.ignoreCache)).apps[params.appName ?? appSpec.name];
		if (!appMetadata) throw new Error(`App not found for creator ${params.creatorAddress} and name ${params.appName ?? appSpec.name}`);
		return new AppClient({
			...params,
			algorand: params.algorand,
			appId: appMetadata.appId
		});
	}
	/**
	* Returns an `AppClient` instance for the current network based on
	* pre-determined network-specific app IDs specified in the ARC-56 app spec.
	*
	* If no IDs are in the app spec or the network isn't recognised, an error is thrown.
	* @param params The parameters to create the app client
	* @returns The `AppClient` instance
	* @example
	* ```typescript
	* const appClient = await AppClient.fromNetwork({
	*   appSpec: appSpec,
	*   algorand: AlgorandClient.mainNet(),
	* })
	*/
	static async fromNetwork(params) {
		const network = await params.algorand.client.network();
		const appSpec = AppClient.normaliseAppSpec(params.appSpec);
		const networkNames = [network.genesisHash];
		if (network.isLocalNet) networkNames.push("localnet");
		if (network.isTestNet) networkNames.push("testnet");
		if (network.isMainNet) networkNames.push("mainnet");
		const networkIndex = Object.keys(appSpec.networks ?? {}).findIndex((n) => networkNames.includes(n));
		if (networkIndex === -1) throw new Error(`No app ID found for network ${asJson(networkNames)} in the app spec`);
		const appId = BigInt(appSpec.networks[networkIndex].appID);
		return new AppClient({
			...params,
			appId,
			appSpec
		});
	}
	/**
	* Takes a string or parsed JSON object that could be ARC-32 or ARC-56 format and
	* normalises it into a parsed ARC-56 contract object.
	* @param spec The spec to normalise
	* @returns The normalised ARC-56 contract object
	* @example
	* ```typescript
	* const arc56AppSpec = AppClient.normaliseAppSpec(appSpec)
	* ```
	*/
	static normaliseAppSpec(spec) {
		const parsedSpec = typeof spec === "string" ? JSON.parse(spec) : spec;
		return "hints" in parsedSpec ? arc32ToArc56(parsedSpec) : parsedSpec;
	}
	/** The ID of the app instance this client is linked to. */
	get appId() {
		return this._appId;
	}
	/** The app address of the app instance this client is linked to. */
	get appAddress() {
		return this._appAddress;
	}
	/** The name of the app (from the ARC-32 / ARC-56 app spec or override). */
	get appName() {
		return this._appName;
	}
	/** The ARC-56 app spec being used */
	get appSpec() {
		return this._appSpec;
	}
	/** A reference to the underlying `AlgorandClient` this app client is using. */
	get algorand() {
		return this._algorand;
	}
	/** Get parameters to create transactions for the current app.
	*
	* A good mental model for this is that these parameters represent a deferred transaction creation.
	* @example Create a transaction in the future using Algorand Client
	* ```typescript
	* const myMethodCall = appClient.params.call({method: 'my_method', args: [123, 'hello']})
	* // ...
	* await algorand.send.AppMethodCall(myMethodCall)
	* ```
	* @example Define a nested transaction as an ABI argument
	* ```typescript
	* const myMethodCall = appClient.params.call({method: 'my_method', args: [123, 'hello']})
	* await appClient.send.call({method: 'my_method2', args: [myMethodCall]})
	* ```
	*/
	get params() {
		return this._paramsMethods;
	}
	/** Create transactions for the current app */
	get createTransaction() {
		return this._createTransactionsMethods;
	}
	/** Send transactions to the current app */
	get send() {
		return this._sendMethods;
	}
	/** Get state (local, global, box) from the current app */
	get state() {
		return {
			/**
			* Methods to access local state for the current app
			* @param address The address of the account to get the local state for
			*/
			local: this._localStateMethods,
			/**
			* Methods to access global state for the current app
			*/
			global: this._globalStateMethods,
			/**
			* Methods to access box storage for the current app
			*/
			box: this._boxStateMethods
		};
	}
	/**
	* Funds Algo into the app account for this app.
	*
	* An alias for `appClient.send.fundAppAccount(params)`.
	* @param params The parameters for the funding transaction
	* @returns The result of the funding
	* @example
	* ```typescript
	* await appClient.fundAppAccount({ amount: algo(1) })
	* ```
	*/
	async fundAppAccount(params) {
		return this.send.fundAppAccount(params);
	}
	/**
	* Returns raw global state for the current app.
	* @returns The global state
	* @example
	* ```typescript
	* const globalState = await appClient.getGlobalState()
	* ```
	* @param options Optional `round` to read the state as of the end of a past round (defaults to the client's pinned round, if any)
	*/
	async getGlobalState(options) {
		return await this._algorand.app.getGlobalState(this.appId, this.readOptions(options));
	}
	/**
	* Returns raw local state for the given account address.
	* @param address The address of the account to get the local state for
	* @param options Optional `round` to read the state as of the end of a past round (defaults to the client's pinned round, if any)
	* @returns The local state
	* @example
	* ```typescript
	* const localState = await appClient.getLocalState('ACCOUNT_ADDRESS')
	* ```
	*/
	async getLocalState(address, options) {
		return await this._algorand.app.getLocalState(this.appId, address, this.readOptions(options));
	}
	/**
	* Returns the names of all current boxes for the current app.
	* @returns The names of the boxes
	* @example
	* ```typescript
	* const boxNames = await appClient.getBoxNames()
	* ```
	* @param options Optional `round` to list the boxes as of the end of a past round (defaults to the client's pinned round, if any)
	*/
	async getBoxNames(options) {
		return await this._algorand.app.getBoxNames(this.appId, this.readOptions(options));
	}
	/**
	* Returns the value of the given box for the current app.
	* @param name The identifier of the box to return
	* @param options Optional `round` to read the box as of the end of a past round (defaults to the client's pinned round, if any)
	* @returns The current box value as a byte array
	* @example
	* ```typescript
	* const boxValue = await appClient.getBoxValue('boxName')
	* ```
	*/
	async getBoxValue(name, options) {
		return await this._algorand.app.getBoxValue(this.appId, name, this.readOptions(options));
	}
	/**
	* Returns the value of the given box for the current app.
	* @param name The identifier of the box to return
	* @param type
	* @param options Optional `round` to read the box as of the end of a past round (defaults to the client's pinned round, if any)
	* @returns The current box value as a byte array
	* @example
	* ```typescript
	* const boxValue = await appClient.getBoxValueFromABIType('boxName', new ABIUintType(32))
	* ```
	*/
	async getBoxValueFromABIType(name, type, options) {
		return await this._algorand.app.getBoxValueFromABIType({
			appId: this.appId,
			boxName: name,
			type,
			...this.readOptions(options)
		});
	}
	/**
	* Returns the values of all current boxes for the current app.
	* Note: This will issue multiple HTTP requests (one per box) and it's not an atomic operation so values may be out of sync.
	* @param filter Optional filter to filter which boxes' values are returned
	* @param options Optional `round` to read the boxes as of the end of a past round (defaults to the client's pinned round, if any)
	* @returns The (name, value) pair of the boxes with values as raw byte arrays
	* @example
	* ```typescript
	* const boxValues = await appClient.getBoxValues()
	* ```
	*/
	async getBoxValues(filter, options) {
		const readOptions = this.readOptions(options);
		const names = (await this.getBoxNames(readOptions)).filter(filter ?? ((_) => true));
		const values = await this._algorand.app.getBoxValues(this.appId, names.map((name) => name.nameRaw), readOptions);
		return names.map((name, i) => ({
			name,
			value: values[i]
		}));
	}
	/**
	* Returns the values of all current boxes for the current app decoded using an ABI Type.
	* Note: This will issue multiple HTTP requests (one per box) and it's not an atomic operation so values may be out of sync.
	* @param type The ABI type to decode the values with
	* @param filter Optional filter to filter which boxes' values are returned
	* @param options Optional `round` to read the boxes as of the end of a past round (defaults to the client's pinned round, if any)
	* @returns The (name, value) pair of the boxes with values as the ABI Value
	* @example
	* ```typescript
	* const boxValues = await appClient.getBoxValuesFromABIType(new ABIUintType(32))
	* ```
	*/
	async getBoxValuesFromABIType(type, filter, options) {
		const readOptions = this.readOptions(options);
		const names = (await this.getBoxNames(readOptions)).filter(filter ?? ((_) => true));
		const values = await this._algorand.app.getBoxValuesFromABIType({
			appId: this.appId,
			boxNames: names.map((name) => name.nameRaw),
			type,
			...readOptions
		});
		return names.map((name, i) => ({
			name,
			value: values[i]
		}));
	}
	/**
	* Takes an error that may include a logic error from a call to the current app and re-exposes the
	* error to include source code information via the source map and ARC-56 spec.
	* @param e The error to parse
	* @param isClearStateProgram Whether or not the code was running the clear state program (defaults to approval program)
	* @returns The new error, or if there was no logic error or source map then the wrapped error with source details
	*/
	async exposeLogicError(e, isClearStateProgram) {
		const pcOffsetMethod = this._appSpec.sourceInfo?.[isClearStateProgram ? "clear" : "approval"]?.pcOffsetMethod;
		let program;
		if (pcOffsetMethod === "cblocks") {
			const appInfo = await this._algorand.app.getById(this.appId, this.readOptions());
			program = isClearStateProgram ? appInfo.clearStateProgram : appInfo.approvalProgram;
		}
		return AppClient.exposeLogicError(e, this._appSpec, {
			isClearStateProgram,
			approvalSourceMap: this._approvalSourceMap,
			clearSourceMap: this._clearSourceMap,
			program
		});
	}
	/**
	* Export the current source maps for the app.
	* @returns The source maps
	*/
	exportSourceMaps() {
		if (!this._approvalSourceMap || !this._clearSourceMap) throw new Error("Unable to export source maps; they haven't been loaded into this client - you need to call create, update, or deploy first");
		return {
			approvalSourceMap: this._approvalSourceMap,
			clearSourceMap: this._clearSourceMap
		};
	}
	/**
	* Import source maps for the app.
	* @param sourceMaps The source maps to import
	*/
	importSourceMaps(sourceMaps) {
		this._approvalSourceMap = new SourceMap(sourceMaps.approvalSourceMap);
		this._clearSourceMap = new SourceMap(sourceMaps.clearSourceMap);
	}
	/**
	* Returns the ABI Method spec for the given method string for the app represented by this application client instance
	* @param methodNameOrSignature The method name or method signature to call if an ABI call is being emitted.
	* e.g. `my_method` or `my_method(unit64,string)bytes`
	* @returns A tuple with: [ARC-56 `Method`, algosdk `ABIMethod`]
	*/
	getABIMethod(methodNameOrSignature) {
		return getArc56Method(methodNameOrSignature, this._appSpec);
	}
	/**
	* Checks for decode errors on the SendAppTransactionResult and maps the return value to the specified type
	* on the ARC-56 method, replacing the `return` property with the decoded type.
	*
	* If the return type is an ARC-56 struct then the struct will be returned.
	*
	* @param result The SendAppTransactionResult to be mapped
	* @param method The method that was called
	* @returns The smart contract response with an updated return value
	*/
	async processMethodCallReturn(result, method) {
		const resultValue = await result;
		return {
			...resultValue,
			return: getArc56ReturnValue(resultValue.return, method, this._appSpec.structs)
		};
	}
	/**
	* Compiles the approval and clear state programs (if TEAL templates provided),
	* performing any provided deploy-time parameter replacement and stores
	* the source maps.
	*
	* If no TEAL templates provided it will use any byte code provided in the app spec.
	*
	* Will store any generated source maps for later use in debugging.
	* @param compilation Any compilation parameters to use
	* @returns The compiled code and any compilation results (including source maps)
	*/
	async compile(compilation) {
		const result = await AppClient.compile(this._appSpec, this._algorand.app, compilation);
		if (result.compiledApproval) {
			this._approvalSourceMap = result.compiledApproval.sourceMap;
			this._lastCompiled.approval = result.compiledApproval.compiledBase64ToBytes;
		}
		if (result.compiledClear) {
			this._clearSourceMap = result.compiledClear.sourceMap;
			this._lastCompiled.clear = result.compiledClear.compiledBase64ToBytes;
		}
		return result;
	}
	/**
	* Takes an error that may include a logic error from a call to the current app and re-exposes the
	* error to include source code information via the source map and ARC-56 spec.
	* @param e The error to parse
	* @param appSpec The app spec for the app
	* @param details Additional information to inform the error
	* @returns The new error, or if there was no logic error or source map then the wrapped error with source details
	*/
	static exposeLogicError(e, appSpec, details) {
		const { isClearStateProgram, approvalSourceMap, clearSourceMap, program } = details;
		const sourceMap = isClearStateProgram ? clearSourceMap : approvalSourceMap;
		const errorDetails = LogicError.parseLogicError(e);
		if (errorDetails === void 0 || errorDetails?.pc === void 0) return e;
		/** The PC value to find in the ARC56 SourceInfo */
		let arc56Pc = errorDetails?.pc;
		const programSourceInfo = isClearStateProgram ? appSpec.sourceInfo?.clear : appSpec.sourceInfo?.approval;
		/** The offset to apply to the PC if using the cblocks pc offset method */
		let cblocksOffset = 0;
		if (programSourceInfo?.pcOffsetMethod === "cblocks") {
			if (program === void 0) throw new Error("Program bytes are required to calculate the ARC56 cblocks PC offset");
			cblocksOffset = getConstantBlockOffset(program);
			arc56Pc = errorDetails.pc - cblocksOffset;
		}
		const errorMessage = (programSourceInfo?.sourceInfo.find((s) => s.pc.includes(arc56Pc)))?.errorMessage;
		if (appSpec.source) {
			let getLineForPc = (inputPc) => sourceMap?.getLocationForPc?.(inputPc)?.line;
			if (sourceMap === void 0) getLineForPc = (inputPc) => {
				const teal = programSourceInfo?.sourceInfo.find((s) => s.pc.includes(inputPc - cblocksOffset))?.teal;
				if (teal === void 0) return void 0;
				return teal - 1;
			};
			e = new LogicError(errorDetails, Buffer.from(isClearStateProgram ? appSpec.source.clear : appSpec.source.approval, "base64").toString().split("\n"), getLineForPc);
		}
		if (errorMessage) {
			const appId = asJson(e).match(/(?<=app=)\d+/)?.[0] || "";
			const txId = asJson(e).match(/(?<=transaction )\S+(?=:)/)?.[0];
			const error = /* @__PURE__ */ new Error(`Runtime error when executing ${appSpec.name} (appId: ${appId}) in transaction ${txId}: ${errorMessage}`);
			error.cause = e;
			return error;
		}
		return e;
	}
	/**
	* Compiles the approval and clear state programs (if TEAL templates provided),
	* performing any provided deploy-time parameter replacement and returns
	* the compiled code and any compilation results (including source maps).
	*
	* If no TEAL templates provided it will use any byte code provided in the app spec.
	*
	* Will store any generated source maps for later use in debugging.
	* @param appSpec The app spec for the app
	* @param appManager The app manager to use for compilation
	* @param compilation Any compilation parameters to use
	* @returns The compiled code and any compilation results (including source maps)
	*/
	static async compile(appSpec, appManager, compilation) {
		const { deployTimeParams, updatable, deletable } = compilation ?? {};
		if (!appSpec.source) {
			if (!appSpec.byteCode?.approval || !appSpec.byteCode?.clear) throw new Error(`Attempt to compile app ${appSpec.name} without source or byteCode`);
			return {
				approvalProgram: Buffer.from(appSpec.byteCode.approval, "base64"),
				clearStateProgram: Buffer.from(appSpec.byteCode.clear, "base64")
			};
		}
		const approvalTemplate = Buffer.from(appSpec.source.approval, "base64").toString("utf-8");
		const compiledApproval = await appManager.compileTealTemplate(approvalTemplate, deployTimeParams, {
			updatable,
			deletable
		});
		const clearTemplate = Buffer.from(appSpec.source.clear, "base64").toString("utf-8");
		const compiledClear = await appManager.compileTealTemplate(clearTemplate, deployTimeParams);
		if (Config.debug) await Config.events.emitAsync("AppCompiled", { sources: [{
			compiledTeal: compiledApproval,
			appName: appSpec.name,
			fileName: "approval"
		}, {
			compiledTeal: compiledClear,
			appName: appSpec.name,
			fileName: "clear"
		}] });
		return {
			approvalProgram: compiledApproval.compiledBase64ToBytes,
			compiledApproval,
			clearStateProgram: compiledClear.compiledBase64ToBytes,
			compiledClear
		};
	}
	/**
	* Returns ABI method arguments ready for a method call params object with default values populated
	* and structs replaced with tuples.
	*
	* It does this by replacing any `undefined` values with the equivalent default value from the given ARC-56 app spec.
	* @param methodNameOrSignature The method name or method signature to call if an ABI call is being emitted.
	* e.g. `my_method` or `my_method(unit64,string)bytes`
	* @param args The arguments to the method with `undefined` for any that should be populated with a default value
	*/
	async getABIArgsWithDefaultValues(methodNameOrSignature, args, sender) {
		const m = getArc56Method(methodNameOrSignature, this._appSpec);
		return await Promise.all(args?.map(async (a, i) => {
			const arg = m.args[i];
			if (!arg) throw new Error(`Unexpected arg at position ${i}. ${m.name} only expects ${m.args.length} args`);
			if (a !== void 0) return arg.struct && typeof a === "object" && !Array.isArray(a) ? getABITupleFromABIStruct(a, this._appSpec.structs[arg.struct], this._appSpec.structs) : a;
			const defaultValue = arg.defaultValue;
			if (defaultValue) switch (defaultValue.source) {
				case "literal": return getABIDecodedValue(Buffer.from(defaultValue.data, "base64"), m.method.args[i].defaultValue?.type ?? m.method.args[i].type, this._appSpec.structs);
				case "method": {
					const method = this.getABIMethod(defaultValue.data);
					const result = await this.send.call({
						method: defaultValue.data,
						args: method.args.map(() => void 0),
						sender
					});
					if (result.return === void 0) throw new Error("Default value method call did not return a value");
					if (typeof result.return === "object" && !(result.return instanceof Uint8Array) && !Array.isArray(result.return) && !(result.return instanceof Address)) return getABITupleFromABIStruct(result.return, this._appSpec.structs[method.returns.struct], this._appSpec.structs);
					return result.return;
				}
				case "local":
				case "global": {
					const state = defaultValue.source === "global" ? await this.getGlobalState() : await this.getLocalState(sender);
					const value = Object.values(state).find((s) => s.keyBase64 === defaultValue.data);
					if (!value) throw new Error(`Preparing default value for argument ${arg.name ?? `arg${i + 1}`} resulted in the failure: The key '${defaultValue.data}' could not be found in ${defaultValue.source} storage`);
					return "valueRaw" in value ? getABIDecodedValue(value.valueRaw, m.method.args[i].defaultValue?.type ?? m.method.args[i].type, this._appSpec.structs) : value.value;
				}
				case "box": {
					const value = await this.getBoxValue(Buffer.from(defaultValue.data, "base64"));
					return getABIDecodedValue(value, m.method.args[i].defaultValue?.type ?? m.method.args[i].type, this._appSpec.structs);
				}
			}
			if (!algosdk.abiTypeIsTransaction(arg.type)) throw new Error(`No value provided for required argument ${arg.name ?? `arg${i + 1}`} in call to method ${m.name}`);
		}) ?? []);
	}
	getBareParamsMethods() {
		return {
			/** Return params for an update call, including deploy-time TEAL template replacements and compilation if provided */
			update: async (params) => {
				return this.getBareParams({
					...params,
					...await this.compile(params)
				}, OnApplicationComplete.UpdateApplicationOC);
			},
			/** Return params for an opt-in call */
			optIn: (params) => {
				return this.getBareParams(params, OnApplicationComplete.OptInOC);
			},
			/** Return params for a delete call */
			delete: (params) => {
				return this.getBareParams(params, OnApplicationComplete.DeleteApplicationOC);
			},
			/** Return params for a clear state call */
			clearState: (params) => {
				return this.getBareParams(params, OnApplicationComplete.ClearStateOC);
			},
			/** Return params for a close out call */
			closeOut: (params) => {
				return this.getBareParams(params, OnApplicationComplete.CloseOutOC);
			},
			/** Return params for a call (defaults to no-op) */
			call: (params) => {
				return this.getBareParams(params, params?.onComplete ?? OnApplicationComplete.NoOpOC);
			}
		};
	}
	getBareCreateTransactionMethods() {
		return {
			/** Returns a transaction for an update call, including deploy-time TEAL template replacements and compilation if provided */
			update: async (params) => {
				return this._algorand.createTransaction.appUpdate(await this.params.bare.update(params));
			},
			/** Returns a transaction for an opt-in call */
			optIn: (params) => {
				return this._algorand.createTransaction.appCall(this.params.bare.optIn(params));
			},
			/** Returns a transaction for a delete call */
			delete: (params) => {
				return this._algorand.createTransaction.appDelete(this.params.bare.delete(params));
			},
			/** Returns a transaction for a clear state call */
			clearState: (params) => {
				return this._algorand.createTransaction.appCall(this.params.bare.clearState(params));
			},
			/** Returns a transaction for a close out call */
			closeOut: (params) => {
				return this._algorand.createTransaction.appCall(this.params.bare.closeOut(params));
			},
			/** Returns a transaction for a call (defaults to no-op) */
			call: (params) => {
				return this._algorand.createTransaction.appCall(this.params.bare.call(params));
			}
		};
	}
	getBareSendMethods() {
		return {
			/** Signs and sends an update call, including deploy-time TEAL template replacements and compilation if provided */
			update: async (params) => {
				const compiled = await this.compile(params);
				return {
					...await this._algorand.send.appUpdate(await this.params.bare.update(params)),
					...compiled
				};
			},
			/** Signs and sends an opt-in call */
			optIn: (params) => {
				return this._algorand.send.appCall(this.params.bare.optIn(params));
			},
			/** Signs and sends a delete call */
			delete: (params) => {
				return this._algorand.send.appDelete(this.params.bare.delete(params));
			},
			/** Signs and sends a clear state call */
			clearState: (params) => {
				return this._algorand.send.appCall(this.params.bare.clearState(params));
			},
			/** Signs and sends a close out call */
			closeOut: (params) => {
				return this._algorand.send.appCall(this.params.bare.closeOut(params));
			},
			/** Signs and sends a call (defaults to no-op) */
			call: (params) => {
				return this._algorand.send.appCall(this.params.bare.call(params));
			}
		};
	}
	getMethodCallParamsMethods() {
		return {
			/**
			* Return params for a payment transaction to fund the app account
			* @param params The parameters for the fund app accont payment transaction
			* @returns The parameters which can be used to create a fund app account payment transaction
			*/
			fundAppAccount: (params) => {
				return {
					...params,
					sender: this.getSender(params.sender),
					signer: this.getSigner(params.sender, params.signer),
					receiver: this.appAddress
				};
			},
			/**
			* Return params for an update ABI call, including deploy-time TEAL template replacements and compilation if provided
			* @param params The parameters for the update ABI method call
			* @returns The parameters which can be used to create an update ABI method call
			*/
			update: async (params) => {
				return await this.getABIParams({
					...params,
					...await this.compile(params)
				}, OnApplicationComplete.UpdateApplicationOC);
			},
			/**
			* Return params for an opt-in ABI call
			* @param params The parameters for the opt-in ABI method call
			* @returns The parameters which can be used to create an opt-in ABI method call
			*/
			optIn: async (params) => {
				return await this.getABIParams(params, OnApplicationComplete.OptInOC);
			},
			/**
			* Return params for an delete ABI call
			* @param params The parameters for the delete ABI method call
			* @returns The parameters which can be used to create a delete ABI method call
			*/
			delete: async (params) => {
				return await this.getABIParams(params, OnApplicationComplete.DeleteApplicationOC);
			},
			/** Return params for an close out ABI call
			* @param params The parameters for the close out ABI method call
			* @returns The parameters which can be used to create a close out ABI method call
			*/
			closeOut: async (params) => {
				return await this.getABIParams(params, OnApplicationComplete.CloseOutOC);
			},
			/** Return params for an ABI call
			* @param params The parameters for the ABI method call
			* @returns The parameters which can be used to create an ABI method call
			*/
			call: async (params) => {
				return await this.getABIParams(params, params.onComplete ?? OnApplicationComplete.NoOpOC);
			}
		};
	}
	getMethodCallSendMethods() {
		return {
			/** Sign and send transactions for a payment transaction to fund the app account
			* @param params The parameters for the fund app account payment transaction
			* @returns The result of send the fund app account payment transaction
			*/
			fundAppAccount: (params) => {
				return this._algorand.send.payment(this.params.fundAppAccount(params));
			},
			/**
			* Sign and send transactions for an update ABI call, including deploy-time TEAL template replacements and compilation if provided
			* @param params The parameters for the update ABI method call
			* @returns The result of sending the update ABI method call
			*/
			update: async (params) => {
				const compiled = await this.compile(params);
				return {
					...await this.processMethodCallReturn(this._algorand.send.appUpdateMethodCall(await this.params.update({ ...params })), getArc56Method(params.method, this._appSpec)),
					...compiled
				};
			},
			/**
			* Sign and send transactions for an opt-in ABI call
			* @param params The parameters for the opt-in ABI method call
			* @returns The result of sending the opt-in ABI method call
			*/
			optIn: async (params) => {
				return this.processMethodCallReturn(this._algorand.send.appCallMethodCall(await this.params.optIn(params)), getArc56Method(params.method, this._appSpec));
			},
			/**
			* Sign and send transactions for a delete ABI call
			* @param params The parameters for the delete ABI method call
			* @returns The result of sending the delete ABI method call
			*/
			delete: async (params) => {
				return this.processMethodCallReturn(this._algorand.send.appDeleteMethodCall(await this.params.delete(params)), getArc56Method(params.method, this._appSpec));
			},
			/**
			* Sign and send transactions for a close out ABI call
			* @param params The parameters for the close out ABI method call
			* @returns The result of sending the close out ABI method call
			*/
			closeOut: async (params) => {
				return this.processMethodCallReturn(this._algorand.send.appCallMethodCall(await this.params.closeOut(params)), getArc56Method(params.method, this._appSpec));
			},
			/**
			* Sign and send transactions for a call (defaults to no-op)
			* @param params The parameters for the ABI method call
			* @returns The result of sending the ABI method call
			*/
			call: async (params) => {
				if ((params.onComplete === OnApplicationComplete.NoOpOC || !params.onComplete) && getArc56Method(params.method, this._appSpec).method.readonly) {
					const readonlyParams = { ...params };
					if (params.coverAppCallInnerTransactionFees && params.maxFee) {
						readonlyParams.staticFee = params.maxFee;
						readonlyParams.extraFee = void 0;
					}
					try {
						const result = await this._algorand.newGroup().addAppCallMethodCall(await this.params.call(readonlyParams)).simulate({
							allowUnnamedResources: params.populateAppCallResources ?? true,
							skipSignatures: true,
							extraOpcodeBudget: await readonlyOpcodeBudget(this._algorand.client.algod),
							...this._round !== void 0 ? { round: this._round } : void 0
						});
						return this.processMethodCallReturn({
							...result,
							transaction: result.transactions.at(-1),
							confirmation: result.confirmations.at(-1),
							return: result.returns?.length ?? false ? result.returns?.at(-1) : void 0
						}, getArc56Method(params.method, this._appSpec));
					} catch (e) {
						const error = e;
						if (params.coverAppCallInnerTransactionFees && error && error.message && error.message.match(/fee ([\w.]+\s+)?too small/)) throw Error(`Fees were too small. You may need to increase the transaction maxFee.`);
						throw e;
					}
				}
				this.assertNotPinned("send a non-readonly call");
				return this.processMethodCallReturn(this._algorand.send.appCallMethodCall(await this.params.call(params)), getArc56Method(params.method, this._appSpec));
			}
		};
	}
	getMethodCallCreateTransactionMethods() {
		return {
			/** Return transaction for a payment transaction to fund the app account
			* @param params The parameters for the fund app account payment transaction
			* @returns A transaction which can be used to fund the app account
			*/
			fundAppAccount: (params) => {
				return this._algorand.createTransaction.payment(this.params.fundAppAccount(params));
			},
			/**
			* Return transactions for an update ABI call, including deploy-time TEAL template replacements and compilation if provided
			* @param params The parameters for the update ABI method call
			* @returns The transactions which can be used to create an update ABI method call
			*/
			update: async (params) => {
				return this._algorand.createTransaction.appUpdateMethodCall(await this.params.update(params));
			},
			/**
			* Return transactions for an opt-in ABI call
			* @param params The parameters for the opt-in ABI method call
			* @returns The transactions which can be used to create an opt-in ABI method call
			*/
			optIn: async (params) => {
				return this._algorand.createTransaction.appCallMethodCall(await this.params.optIn(params));
			},
			/**
			* Return transactions for a delete ABI call
			* @param params The parameters for the delete ABI method call
			* @returns The transactions which can be used to create a delete ABI method call
			*/
			delete: async (params) => {
				return this._algorand.createTransaction.appDeleteMethodCall(await this.params.delete(params));
			},
			/**
			* Return transactions for a close out ABI call
			* @param params The parameters for the close out ABI method call
			* @returns The transactions which can be used to create a close out ABI method call
			*/
			closeOut: async (params) => {
				return this._algorand.createTransaction.appCallMethodCall(await this.params.closeOut(params));
			},
			/**
			* Return transactions for an ABI call (defaults to no-op)
			* @param params The parameters for the ABI method call
			* @returns The transactions which can be used to create an ABI method call
			*/
			call: async (params) => {
				return this._algorand.createTransaction.appCallMethodCall(await this.params.call(params));
			}
		};
	}
	/** Returns the sender for a call, using the provided sender or using the `defaultSender`
	* if none provided and throws an error if neither provided */
	getSender(sender) {
		if (!sender && !this._defaultSender) throw new Error(`No sender provided and no default sender present in app client for call to app ${this._appName}`);
		return typeof sender === "string" ? Address.fromString(sender) : sender ?? this._defaultSender;
	}
	/** Returns the signer for a call, using the provided signer or the `defaultSigner`
	* if no signer was provided and the sender resolves to the default sender, the call will use default signer
	* or `undefined` otherwise (so the signer is resolved from `AlgorandClient`) */
	getSigner(sender, signer) {
		return signer ?? (!sender || sender === this._defaultSender ? this._defaultSigner : void 0);
	}
	getBareParams(params, onComplete) {
		return {
			...params,
			appId: this._appId,
			sender: this.getSender(params?.sender),
			signer: this.getSigner(params?.sender, params?.signer),
			onComplete
		};
	}
	async getABIParams(params, onComplete) {
		const sender = this.getSender(params.sender);
		const method = getArc56Method(params.method, this._appSpec);
		const args = await this.getABIArgsWithDefaultValues(params.method, params.args, sender);
		return {
			...params,
			appId: this._appId,
			sender,
			signer: this.getSigner(params.sender, params.signer),
			method,
			onComplete,
			args
		};
	}
	/** Make the given call and catch any errors, augmenting with debugging information before re-throwing. */
	handleCallErrors = async (e) => {
		if (this.appId === 0n) {
			if (e.sentTransactions === void 0) return e;
			const txn = e.sentTransactions.find((t) => e.message.includes(t.txID()));
			const programsDefinedAndEqual = (a, b) => {
				if (a === void 0 || b === void 0) return false;
				if (a.length !== b.length) return false;
				for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
				return true;
			};
			if (!programsDefinedAndEqual(txn?.applicationCall?.clearProgram, this._lastCompiled.clear) || !programsDefinedAndEqual(txn?.applicationCall?.approvalProgram, this._lastCompiled?.approval)) return e;
		} else if (!new RegExp(`app=${this._appId.toString()}(?!\\d)`).test(e.message)) return e;
		const logicError = await this.exposeLogicError(e);
		if (logicError instanceof LogicError) {
			let currentLine = logicError.teal_line - logicError.lines - 1;
			const stackWithLines = logicError.stack?.split("\n").map((line) => `${currentLine += 1}: ${line}`).join("\n");
			Config.logger.error(`${logicError.message}\n\n${stackWithLines}`);
		}
		return logicError;
	};
	getBoxMethods() {
		const that = this;
		const stateMethods = {
			/**
			* Returns all single-key state values in a record keyed by the key name and the value a decoded ABI value.
			*/
			getAll: async () => {
				return Object.fromEntries(await Promise.all(Object.keys(that._appSpec.state.keys.box).map(async (key) => [key, await stateMethods.getValue(key)])));
			},
			/**
			* Returns a single state value for the current app with the value a decoded ABI value.
			* @param name The name of the state value to retrieve the value for
			* @returns
			*/
			getValue: async (name) => {
				const metadata = that._appSpec.state.keys.box[name];
				const value = await that.getBoxValue(Buffer.from(metadata.key, "base64"));
				return getABIDecodedValue(value, metadata.valueType, that._appSpec.structs);
			},
			/**
			*
			* @param mapName The name of the map to read from
			* @param key The key within the map (without any map prefix) as either a Buffer with the bytes or a value
			*  that will be converted to bytes by encoding it using the specified ABI key type
			*  in the ARC-56 spec
			*/
			getMapValue: async (mapName, key) => {
				const metadata = that._appSpec.state.maps.box[mapName];
				const prefix = Buffer.from(metadata.prefix ?? "", "base64");
				const encodedKey = Buffer.concat([prefix, getABIEncodedValue(key, metadata.keyType, that._appSpec.structs)]);
				const base64Key = Buffer.from(encodedKey).toString("base64");
				const value = await that.getBoxValue(Buffer.from(base64Key, "base64"));
				return getABIDecodedValue(value, metadata.valueType, that._appSpec.structs);
			},
			/**
			*
			* @param mapName The name of the map to read from
			* @param key The key within the map as either a Buffer with the bytes or a value
			*  that will be converted to bytes by encoding it using the specified ABI key type
			*  in the ARC-56 spec
			* @param appState
			*/
			getMap: async (mapName) => {
				const metadata = that._appSpec.state.maps.box[mapName];
				const prefix = Buffer.from(metadata.prefix ?? "", "base64");
				const boxNames = await that.getBoxNames();
				return new Map(await Promise.all(boxNames.filter((b) => binaryStartsWith(b.nameRaw, prefix)).map(async (b) => {
					return [getABIDecodedValue(b.nameRaw.slice(prefix.length), metadata.keyType, that._appSpec.structs), getABIDecodedValue(await that.getBoxValue(b.nameRaw), metadata.valueType, that._appSpec.structs)];
				})));
			}
		};
		return stateMethods;
	}
	getStateMethods(stateGetter, keyGetter, mapGetter) {
		const that = this;
		const stateMethods = {
			/**
			* Returns all single-key state values in a record keyed by the key name and the value a decoded ABI value.
			*/
			getAll: async () => {
				const appState = await stateGetter();
				return Object.fromEntries(await Promise.all(Object.keys(keyGetter()).map(async (key) => [key, await stateMethods.getValue(key, appState)])));
			},
			/**
			* Returns a single state value for the current app with the value a decoded ABI value.
			* @param name The name of the state value to retrieve the value for
			* @param appState Optional cached value of the current state
			* @returns
			*/
			getValue: async (name, appState) => {
				const state = Object.values(appState ?? await stateGetter());
				const metadata = keyGetter()[name];
				if (metadata === void 0) throw new Error(`Attempted to get state value ${name}, but it does not exist`);
				const value = state.find((s) => s.keyBase64 === metadata.key);
				if (value && "valueRaw" in value) return getABIDecodedValue(value.valueRaw, metadata.valueType, that._appSpec.structs);
				return value?.value;
			},
			/**
			* Returns a single value from the given map for the current app with the value a decoded ABI value.
			* @param mapName The name of the map to read from
			* @param key The key within the map (without any map prefix) as either a Buffer with the bytes or a value
			*  that will be converted to bytes by encoding it using the specified ABI key type
			*  in the ARC-56 spec
			* @param appState Optional cached value of the current state
			*/
			getMapValue: async (mapName, key, appState) => {
				const state = Object.values(appState ?? await stateGetter());
				const metadata = mapGetter()[mapName];
				const prefix = Buffer.from(metadata.prefix ?? "", "base64");
				const encodedKey = Buffer.concat([prefix, getABIEncodedValue(key, metadata.keyType, that._appSpec.structs)]);
				const base64Key = Buffer.from(encodedKey).toString("base64");
				const value = state.find((s) => s.keyBase64 === base64Key);
				if (value && "valueRaw" in value) return getABIDecodedValue(value.valueRaw, metadata.valueType, that._appSpec.structs);
				return value?.value;
			},
			/**
			* Returns all map values for the given map.
			* @param mapName The name of the map to read from
			* @param appState Optional cached value of the current state
			* @returns A map of all key-value pairs in the map as a `Record<string, ABIValue>`
			*/
			getMap: async (mapName) => {
				const state = Object.values(await stateGetter());
				const metadata = mapGetter()[mapName];
				const prefix = Buffer.from(metadata.prefix ?? "", "base64");
				return new Map(state.filter((s) => binaryStartsWith(s.keyRaw, prefix)).map((s) => {
					const key = s.keyRaw.slice(prefix.length);
					return [getABIDecodedValue(key, metadata.keyType, this._appSpec.structs), getABIDecodedValue("valueRaw" in s ? s.valueRaw : s.value, metadata.valueType, this._appSpec.structs)];
				}));
			}
		};
		return stateMethods;
	}
};
/**
* @deprecated Use `AppClient` instead e.g. via `algorand.client.getAppClientById` or
* `algorand.client.getAppClientByCreatorAndName`.
* If you want to `create` or `deploy` then use `AppFactory` e.g. via `algorand.client.getAppFactory`,
* which will in turn give you an `AppClient` instance against the created/deployed app to make other calls.
*
* Application client - a class that wraps an ARC-0032 app spec and provides high productivity methods to deploy and call the app */
var ApplicationClient = class {
	algod;
	indexer;
	appSpec;
	sender;
	params;
	existingDeployments;
	deployTimeParams;
	_appId;
	_appAddress;
	_creator;
	_appName;
	_approvalSourceMap;
	_clearSourceMap;
	/**
	* @deprecated Use `AppClient` instead e.g. via `algorand.client.getAppClientById` or
	* `algorand.client.getAppClientByCreatorAndName`.
	* If you want to `create` or `deploy` then use `AppFactory` e.g. via `algorand.client.getAppFactory`,
	* which will in turn give you an `AppClient` instance against the created/deployed app to make other calls.
	*
	* Create a new ApplicationClient instance
	* @param appDetails The details of the app
	* @param algod An algod instance
	*/
	constructor(appDetails, algod) {
		const { app, sender, params, deployTimeParams, ...appIdentifier } = appDetails;
		this.algod = algod;
		this.appSpec = typeof app == "string" ? JSON.parse(app) : app;
		this._appName = appIdentifier.name ?? this.appSpec.contract.name;
		this.deployTimeParams = deployTimeParams;
		if (appIdentifier.resolveBy === "id") {
			if (appIdentifier.id < 0) throw new Error(`Attempt to create application client with invalid app id of ${appIdentifier.id}`);
			this._appId = appIdentifier.id;
		} else {
			this._appId = 0;
			this._creator = appIdentifier.creatorAddress?.toString();
			if (appIdentifier.findExistingUsing instanceof Indexer) this.indexer = appIdentifier.findExistingUsing;
			else {
				if (appIdentifier.findExistingUsing.creator !== this._creator) throw new Error(`Attempt to create application client with invalid existingDeployments against a different creator (${appIdentifier.findExistingUsing.creator}) instead of expected creator ${this._creator}`);
				this.existingDeployments = appIdentifier.findExistingUsing;
			}
		}
		this._appAddress = algosdk.getApplicationAddress(this._appId).toString();
		this.sender = sender;
		this.params = params;
	}
	/**
	* @deprecated Use `AppClient.compile()` instead.
	*
	* Compiles the approval and clear state programs and sets up the source map.
	* @param compilation The deploy-time parameters for the compilation
	* @returns The compiled approval and clear state programs
	*/
	async compile(compilation) {
		const { deployTimeParams, updatable, deletable } = compilation ?? {};
		const approvalTemplate = Buffer.from(this.appSpec.source.approval, "base64").toString("utf-8");
		const approval = replaceDeployTimeControlParams(performTemplateSubstitution(approvalTemplate, deployTimeParams ?? this.deployTimeParams), {
			updatable,
			deletable
		});
		const approvalCompiled = await compileTeal(approval, this.algod);
		this._approvalSourceMap = approvalCompiled?.sourceMap;
		const clearTemplate = Buffer.from(this.appSpec.source.clear, "base64").toString("utf-8");
		const clear = performTemplateSubstitution(clearTemplate, deployTimeParams ?? this.deployTimeParams);
		const clearCompiled = await compileTeal(clear, this.algod);
		this._clearSourceMap = clearCompiled?.sourceMap;
		if (Config.debug) await Config.events.emitAsync("AppCompiled", { sources: [{
			compiledTeal: approvalCompiled,
			appName: this._appName,
			fileName: "approval"
		}, {
			compiledTeal: clearCompiled,
			appName: this._appName,
			fileName: "clear"
		}] });
		return {
			approvalCompiled,
			clearCompiled
		};
	}
	/**
	* Export the current source maps for the app.
	* @returns The source maps
	*/
	exportSourceMaps() {
		if (!this._approvalSourceMap || !this._clearSourceMap) throw new Error("Unable to export source maps; they haven't been loaded into this client - you need to call create, update, or deploy first");
		return {
			approvalSourceMap: this._approvalSourceMap,
			clearSourceMap: this._clearSourceMap
		};
	}
	/**
	* Import source maps for the app.
	* @param sourceMaps The source maps to import
	*/
	importSourceMaps(sourceMaps) {
		this._approvalSourceMap = new SourceMap(sourceMaps.approvalSourceMap);
		this._clearSourceMap = new SourceMap(sourceMaps.clearSourceMap);
	}
	/**
	* @deprecated Use `deploy` from an `AppFactory` instance instead.
	*
	* Idempotently deploy (create, update/delete if changed) an app against the given name via the given creator account, including deploy-time template placeholder substitutions.
	*
	* To understand the architecture decisions behind this functionality please see https://github.com/algorandfoundation/algokit-cli/blob/main/docs/src/content/docs/architecture-decisions/2023-01-12_smart-contract-deployment.md
	*
	* **Note:** if there is a breaking state schema change to an existing app (and `onSchemaBreak` is set to `'replace'`) the existing app will be deleted and re-created.
	*
	* **Note:** if there is an update (different TEAL code) to an existing app (and `onUpdate` is set to `'replace'`) the existing app will be deleted and re-created.
	* @param deploy Deployment details
	* @returns The metadata and transaction result(s) of the deployment, or just the metadata if it didn't need to issue transactions
	*/
	async deploy(deploy) {
		const { schema, sender: deploySender, version, allowUpdate, allowDelete, sendParams, createArgs, createOnCompleteAction, updateArgs, deleteArgs, ...deployArgs } = deploy ?? {};
		if (this._appId !== 0) throw new Error(`Attempt to deploy app which already has an app id of ${this._appId}`);
		const sender = deploySender ?? this.sender;
		if (!sender) throw new Error("No sender provided, unable to deploy app");
		const from = sender ?? this.sender;
		if (!this._creator) throw new Error("Attempt to `deploy` a contract without specifying `resolveBy: 'creatorAndName'` in the constructor");
		if (this._creator !== getSenderAddress(from)) throw new Error(`Attempt to deploy contract with a sender address (${getSenderAddress(from)}) that differs from the given creator address for this application client: ${this._creator}`);
		const approval = Buffer.from(this.appSpec.source.approval, "base64").toString("utf-8");
		const compilation = {
			deployTimeParams: deployArgs.deployTimeParams,
			updatable: allowUpdate !== void 0 ? allowUpdate : getDeployTimeControl(approval, this.appSpec, UPDATABLE_TEMPLATE_NAME, "update_application"),
			deletable: allowDelete !== void 0 ? allowDelete : getDeployTimeControl(approval, this.appSpec, DELETABLE_TEMPLATE_NAME, "delete_application")
		};
		const { approvalCompiled, clearCompiled } = await this.compile(compilation);
		try {
			await this.getAppReference();
			const result = await deployApp({
				from: sender,
				approvalProgram: approvalCompiled.compiledBase64ToBytes,
				clearStateProgram: clearCompiled.compiledBase64ToBytes,
				metadata: {
					name: this._appName,
					version: version ?? "1.0",
					updatable: compilation.updatable,
					deletable: compilation.deletable
				},
				schema: {
					globalByteSlices: this.appSpec.state.global.num_byte_slices,
					globalInts: this.appSpec.state.global.num_uints,
					localByteSlices: this.appSpec.state.local.num_byte_slices,
					localInts: this.appSpec.state.local.num_uints,
					...schema
				},
				transactionParams: this.params,
				...sendParams ?? {},
				existingDeployments: this.existingDeployments,
				createArgs: await this.getCallArgs(createArgs, sender),
				createOnCompleteAction,
				updateArgs: await this.getCallArgs(updateArgs, sender),
				deleteArgs: await this.getCallArgs(deleteArgs, sender),
				...deployArgs
			}, this.algod, this.indexer);
			if (result.operationPerformed === "nothing") return result;
			if (!this.existingDeployments) throw new Error("Expected existingDeployments to be present");
			const { transaction, confirmation, operationPerformed, ...appMetadata } = result;
			this.existingDeployments = {
				creator: this.existingDeployments.creator,
				apps: {
					...this.existingDeployments.apps,
					[this._appName]: appMetadata
				}
			};
			return {
				...result,
				compiledApproval: approvalCompiled,
				compiledClear: clearCompiled
			};
		} catch (e) {
			throw this.exposeLogicError(e);
		}
	}
	/**
	* @deprecated Use `create` from an `AppFactory` instance instead.
	*
	* Creates a smart contract app, returns the details of the created app.
	* @param create The parameters to create the app with
	* @returns The details of the created app, or the transaction to create it if `skipSending` and the compilation result
	*/
	async create(create) {
		const { sender: createSender, note, sendParams, deployTimeParams, updatable, deletable, onCompleteAction, schema, ...args } = create ?? {};
		if (this._appId !== 0) throw new Error(`Attempt to create app which already has an app id of ${this._appId}`);
		const sender = createSender ?? this.sender;
		if (!sender) throw new Error("No sender provided, unable to create app");
		const { approvalCompiled, clearCompiled } = await this.compile(create);
		try {
			const result = await createApp({
				from: sender,
				approvalProgram: approvalCompiled.compiledBase64ToBytes,
				clearStateProgram: clearCompiled.compiledBase64ToBytes,
				schema: {
					globalByteSlices: this.appSpec.state.global.num_byte_slices,
					globalInts: this.appSpec.state.global.num_uints,
					localByteSlices: this.appSpec.state.local.num_byte_slices,
					localInts: this.appSpec.state.local.num_uints,
					...schema
				},
				onCompleteAction,
				args: await this.getCallArgs(args, sender),
				note,
				transactionParams: this.params,
				...sendParams ?? {}
			}, this.algod);
			if (result.confirmation) {
				this._appId = result.confirmation.applicationIndex;
				this._appAddress = getApplicationAddress(this._appId).toString();
			}
			return {
				...result,
				compiledApproval: approvalCompiled,
				compiledClear: clearCompiled
			};
		} catch (e) {
			throw await this.exposeLogicError(e);
		}
	}
	/**
	* @deprecated Use `appClient.send.update` or `appClient.createTransaction.update` from an `AppClient` instance instead.
	*
	* Updates the smart contract app.
	* @param update The parameters to update the app with
	* @returns The transaction send result and the compilation result
	*/
	async update(update) {
		const { sender: updateSender, note, sendParams, deployTimeParams, updatable, deletable, ...args } = update ?? {};
		if (this._appId === 0) throw new Error(`Attempt to update app which doesn't have an app id defined`);
		const sender = updateSender ?? this.sender;
		if (!sender) throw new Error("No sender provided, unable to create app");
		const { approvalCompiled, clearCompiled } = await this.compile(update);
		try {
			return {
				...await updateApp({
					appId: this._appId,
					from: sender,
					approvalProgram: approvalCompiled.compiledBase64ToBytes,
					clearStateProgram: clearCompiled.compiledBase64ToBytes,
					args: await this.getCallArgs(args, sender),
					note,
					transactionParams: this.params,
					...sendParams ?? {}
				}, this.algod),
				compiledApproval: approvalCompiled,
				compiledClear: clearCompiled
			};
		} catch (e) {
			throw await this.exposeLogicError(e);
		}
	}
	/**
	* @deprecated Use `appClient.send.call` or `appClient.createTransaction.call` from an `AppClient` instance instead.
	*
	* Issues a no_op (normal) call to the app.
	* @param call The call details.
	* @returns The result of the call
	*/
	async call(call) {
		if (call?.method && !call.sendParams?.skipSending && !call.sendParams?.atc && this.appSpec.hints[this.getABIMethodSignature(this.getABIMethod(call.method))].read_only) {
			const atc = new AtomicTransactionComposer();
			await this.callOfType({
				...call,
				sendParams: {
					...call.sendParams,
					atc
				}
			}, "no_op");
			const result = await atc.simulate(this.algod);
			if (result.simulateResponse.txnGroups.some((group) => group.failureMessage)) throw new Error(result.simulateResponse.txnGroups.find((x) => x.failureMessage)?.failureMessage);
			const txns = atc.buildGroup();
			return {
				transaction: txns[txns.length - 1].txn,
				confirmation: result.simulateResponse.txnGroups[0].txnResults.at(-1)?.txnResult,
				confirmations: result.simulateResponse.txnGroups[0].txnResults.map((t) => t.txnResult),
				transactions: txns.map((t) => t.txn),
				return: result.methodResults?.length ?? false ? result.methodResults[result.methodResults.length - 1] : void 0
			};
		}
		return await this.callOfType(call, "no_op");
	}
	/**
	* @deprecated Use `appClient.send.optIn` or `appClient.createTransaction.optIn` from an `AppClient` instance instead.
	*
	* Issues a opt_in call to the app.
	* @param call The call details.
	* @returns The result of the call
	*/
	async optIn(call) {
		return await this.callOfType(call, "opt_in");
	}
	/**
	* @deprecated Use `appClient.send.closeOut` or `appClient.createTransaction.closeOut` from an `AppClient` instance instead.
	*
	* Issues a close_out call to the app.
	* @param call The call details.
	* @returns The result of the call
	*/
	async closeOut(call) {
		return await this.callOfType(call, "close_out");
	}
	/**
	* @deprecated Use `appClient.send.clearState` or `appClient.createTransaction.clearState` from an `AppClient` instance instead.
	*
	* Issues a clear_state call to the app.
	* @param call The call details.
	* @returns The result of the call
	*/
	async clearState(call) {
		return await this.callOfType(call, "clear_state");
	}
	/**
	* @deprecated Use `appClient.send.delete` or `appClient.createTransaction.delete` from an `AppClient` instance instead.
	*
	* Issues a delete_application call to the app.
	* @param call The call details.
	* @returns The result of the call
	*/
	async delete(call) {
		return await this.callOfType(call, "delete_application");
	}
	/**
	* @deprecated Use `appClient.send.call` or `appClient.createTransaction.call` from an `AppClient` instance instead.
	*
	* Issues a call to the app with the given call type.
	* @param call The call details.
	* @param callType The call type
	* @returns The result of the call
	*/
	async callOfType(call = {}, callType) {
		const { sender: callSender, note, sendParams, ...args } = call;
		const sender = callSender ?? this.sender;
		if (!sender) throw new Error("No sender provided, unable to call app");
		const appMetadata = await this.getAppReference();
		if (appMetadata.appId === 0) throw new Error(`Attempt to call an app that can't be found '${this._appName}' for creator '${this._creator}'.`);
		try {
			return await callApp({
				appId: appMetadata.appId,
				callType,
				from: sender,
				args: await this.getCallArgs(args, sender),
				note,
				transactionParams: this.params,
				...sendParams ?? {}
			}, this.algod);
		} catch (e) {
			throw this.exposeLogicError(e);
		}
	}
	/**
	* Funds Algo into the app account for this app.
	* @param fund The parameters for the funding or the funding amount
	* @returns The result of the funding
	*/
	async fundAppAccount(fund) {
		const { amount, sender, note, sendParams } = "microAlgos" in fund ? { amount: fund } : fund;
		if (!sender && !this.sender) throw new Error("No sender provided, unable to call app");
		const ref = await this.getAppReference();
		return legacySendTransactionBridge(this.algod, sender ?? this.sender, sendParams ?? {}, {
			receiver: ref.appAddress,
			sender: getSenderAddress(sender ?? this.sender),
			amount,
			note: encodeTransactionNote(note)
		}, (c) => c.payment, (c) => c.payment, this.params);
	}
	/**
	* Returns global state for the current app.
	* @returns The global state
	*/
	async getGlobalState() {
		const appRef = await this.getAppReference();
		if (appRef.appId === 0) throw new Error("No app has been created yet, unable to get global state");
		return getAppGlobalState(appRef.appId, this.algod);
	}
	/**
	* Returns local state for the given account / account address.
	* @returns The global state
	*/
	async getLocalState(account) {
		const appRef = await this.getAppReference();
		if (appRef.appId === 0) throw new Error("No app has been created yet, unable to get global state");
		return getAppLocalState(appRef.appId, account, this.algod);
	}
	/**
	* Returns the names of all current boxes for the current app.
	* @returns The names of the boxes
	*/
	async getBoxNames() {
		const appRef = await this.getAppReference();
		if (appRef.appId === 0) throw new Error("No app has been created yet, unable to get global state");
		return await getAppBoxNames(appRef.appId, this.algod);
	}
	/**
	* Returns the value of the given box for the current app.
	* @param name The name of the box to return either as a string, binary array or `BoxName`
	* @returns The current box value as a byte array
	*/
	async getBoxValue(name) {
		const appRef = await this.getAppReference();
		if (appRef.appId === 0) throw new Error("No app has been created yet, unable to get global state");
		return await getAppBoxValue(appRef.appId, name, this.algod);
	}
	/**
	* Returns the value of the given box for the current app.
	* @param name The name of the box to return either as a string, binary array or `BoxName`
	* @param type
	* @returns The current box value as a byte array
	*/
	async getBoxValueFromABIType(name, type) {
		const appRef = await this.getAppReference();
		if (appRef.appId === 0) throw new Error("No app has been created yet, unable to get global state");
		return await getAppBoxValueFromABIType({
			appId: appRef.appId,
			boxName: name,
			type
		}, this.algod);
	}
	/**
	* Returns the values of all current boxes for the current app.
	* Note: This will issue multiple HTTP requests (one per box) and it's not an atomic operation so values may be out of sync.
	* @param filter Optional filter to filter which boxes' values are returned
	* @returns The (name, value) pair of the boxes with values as raw byte arrays
	*/
	async getBoxValues(filter) {
		const appRef = await this.getAppReference();
		if (appRef.appId === 0) throw new Error("No app has been created yet, unable to get global state");
		const names = await this.getBoxNames();
		return await Promise.all(names.filter(filter ?? ((_) => true)).map(async (boxName) => ({
			name: boxName,
			value: await getAppBoxValue(appRef.appId, boxName, this.algod)
		})));
	}
	/**
	* Returns the values of all current boxes for the current app decoded using an ABI Type.
	* Note: This will issue multiple HTTP requests (one per box) and it's not an atomic operation so values may be out of sync.
	* @param type The ABI type to decode the values with
	* @param filter Optional filter to filter which boxes' values are returned
	* @returns The (name, value) pair of the boxes with values as the ABI Value
	*/
	async getBoxValuesFromABIType(type, filter) {
		const appRef = await this.getAppReference();
		if (appRef.appId === 0) throw new Error("No app has been created yet, unable to get global state");
		const names = await this.getBoxNames();
		return await Promise.all(names.filter(filter ?? ((_) => true)).map(async (boxName) => ({
			name: boxName,
			value: await getAppBoxValueFromABIType({
				appId: appRef.appId,
				boxName,
				type
			}, this.algod)
		})));
	}
	/**
	* @deprecated Use `appClient.params.*` from an `AppClient` instance instead.
	*
	* Returns the arguments for an app call for the given ABI method or raw method specification.
	* @param args The call args specific to this application client
	* @param sender The sender of this call. Will be used to fetch any default argument values if applicable
	* @returns The call args ready to pass into an app call
	*/
	async getCallArgs(args, sender) {
		if (!args) return;
		if (args.method) {
			const abiMethod = this.getABIMethodParams(args.method);
			if (!abiMethod) throw new Error(`Attempt to call ABI method ${args.method}, but it wasn't found`);
			const methodSignature = this.getABIMethodSignature(abiMethod);
			return {
				...args,
				method: abiMethod,
				methodArgs: await Promise.all(args.methodArgs.map(async (arg, index) => {
					if (arg !== void 0) return arg;
					const argName = abiMethod.args[index].name;
					const defaultValueStrategy = argName && this.appSpec.hints?.[methodSignature]?.default_arguments?.[argName];
					if (!defaultValueStrategy) throw new Error(`Argument at position ${index} with the name ${argName} is undefined and does not have a default value strategy`);
					switch (defaultValueStrategy.source) {
						case "constant": return defaultValueStrategy.data;
						case "abi-method": {
							const method = defaultValueStrategy.data;
							return (await this.callOfType({
								method: this.getABIMethodSignature(method),
								methodArgs: method.args.map(() => void 0),
								sender
							}, "no_op")).return?.returnValue;
						}
						case "local-state":
						case "global-state": {
							const state = defaultValueStrategy.source === "global-state" ? await this.getGlobalState() : await this.getLocalState(sender);
							const key = defaultValueStrategy.data;
							if (key in state) return state[key].value;
							else throw new Error(`Preparing default value for argument at position ${index} with the name ${argName} resulted in the failure: The key '${key}' could not be found in ${defaultValueStrategy.source}`);
						}
					}
				}))
			};
		} else return args;
	}
	/**
	* @deprecated Use `appClient.getABIMethod` instead.
	*
	* Returns the ABI Method parameters for the given method name string for the app represented by this application client instance
	* @param method Either the name of the method or the ABI method spec definition string
	* @returns The ABI method params for the given method
	*/
	getABIMethodParams(method) {
		if (!method.includes("(")) {
			const methods = this.appSpec.contract.methods.filter((m) => m.name === method);
			if (methods.length > 1) throw new Error(`Received a call to method ${method} in contract ${this._appName}, but this resolved to multiple methods; please pass in an ABI signature instead: ${methods.map(this.getABIMethodSignature).join(", ")}`);
			return methods[0];
		}
		return this.appSpec.contract.methods.find((m) => this.getABIMethodSignature(m) === method);
	}
	/**
	* Returns the ABI Method for the given method name string for the app represented by this application client instance
	* @param method Either the name of the method or the ABI method spec definition string
	* @returns The ABI method for the given method
	*/
	getABIMethod(method) {
		const methodParams = this.getABIMethodParams(method);
		return methodParams ? new ABIMethod(methodParams) : void 0;
	}
	/**
	* @deprecated Use `appClient.appId` and `appClient.appAddress` from an `AppClient` instance instead.
	*
	* Gets the reference information for the current application instance.
	* `appId` will be 0 if it can't find an app.
	* @returns The app reference, or if deployed using the `deploy` method, the app metadata too
	*/
	async getAppReference() {
		if (!this.existingDeployments && this._creator) this.existingDeployments = await getCreatorAppsByName(this._creator, this.indexer);
		if (this.existingDeployments && this._appId === 0) {
			const app = this.existingDeployments.apps[this._appName];
			if (!app) return {
				appId: 0,
				appAddress: getApplicationAddress(0).toString()
			};
			return app;
		}
		return {
			appId: this._appId,
			appAddress: this._appAddress
		};
	}
	/**
	* Takes an error that may include a logic error from a smart contract call and re-exposes the error to include source code information via the source map.
	* This is automatically used within `ApplicationClient` but if you pass `skipSending: true` e.g. if doing a group transaction
	*  then you can use this in a try/catch block to get better debugging information.
	* @param e The error to parse
	* @param isClear Whether or not the code was running the clear state program
	* @returns The new error, or if there was no logic error or source map then the wrapped error with source details
	*/
	exposeLogicError(e, isClear) {
		if (!isClear && this._approvalSourceMap == void 0 || isClear && this._clearSourceMap == void 0) return e;
		const errorDetails = LogicError.parseLogicError(e);
		if (errorDetails !== void 0) return new LogicError(errorDetails, Buffer.from(isClear ? this.appSpec.source.clear : this.appSpec.source.approval, "base64").toString().split("\n"), (pc) => (isClear ? this._clearSourceMap : this._approvalSourceMap)?.getLocationForPc(pc)?.line);
		else return e;
	}
	getABIMethodSignature(method) {
		return "getSignature" in method ? method.getSignature() : new ABIMethod(method).getSignature();
	}
};
//#endregion
export { AppClient, ApplicationClient };

//# sourceMappingURL=app-client.mjs.map