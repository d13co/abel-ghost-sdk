import { AsyncEventEmitter } from './async-event-emitter';
import { Logger } from './logging';
/** The AlgoKit configuration type */
export interface Config {
    /** Logger */
    logger: Logger;
    /** Whether or not debug mode is enabled */
    debug: boolean;
    /** The path to the project root directory */
    projectRoot: string | null;
    /** Indicates whether to trace all operations */
    traceAll: boolean;
    /** The size of the trace buffer in megabytes */
    traceBufferSizeMb: number;
    /** The maximum depth to search for a specific file */
    maxSearchDepth: number;
    /**
     * Whether to enable populateAppCallResources in sendParams by default.
     * Default value is false.
     */
    populateAppCallResources: boolean;
    events: AsyncEventEmitter;
}
/** Updatable AlgoKit config */
export declare class UpdatableConfig implements Readonly<Config> {
    private config;
    get populateAppCallResources(): boolean;
    get logger(): Logger;
    get debug(): boolean;
    get projectRoot(): string | null;
    get traceAll(): boolean;
    get traceBufferSizeMb(): number;
    get maxSearchDepth(): number;
    get events(): AsyncEventEmitter;
    /**
     * Returns the current logger, or the null logger if true is passed in to `returnNullLogger`
     * @param returnNullLogger Whether or not to return the null logger
     * @returns The requested logger
     */
    getLogger(returnNullLogger?: boolean): Logger;
    /**
     * Temporarily run with debug set to true.
     * @param lambda A lambda expression with code to run with debug config set to true
     */
    withDebug(lambda: () => unknown): void;
    constructor();
    /**
     * Update the AlgoKit configuration with your own configuration settings
     * @param newConfig Partial or complete config to replace
     */
    configure(newConfig: Partial<Config>): void;
}
