Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../_virtual/_rolldown/runtime.js");
let algosdk = require("algosdk");
algosdk = require_runtime.__toESM(algosdk);
//#region src/types/account.ts
/**
* The account name identifier used for fund dispensing in test environments
*/
const DISPENSER_ACCOUNT = "DISPENSER";
/** Account wrapper that supports partial or full multisig signing. */
var MultisigAccount = class {
	_params;
	_signingAccounts;
	_addr;
	_signer;
	/** The parameters for the multisig account */
	get params() {
		return this._params;
	}
	/** The list of accounts that are present to sign */
	get signingAccounts() {
		return this._signingAccounts;
	}
	/** The address of the multisig account */
	get addr() {
		return this._addr;
	}
	/** The transaction signer for the multisig account */
	get signer() {
		return this._signer;
	}
	constructor(multisigParams, signingAccounts) {
		this._params = multisigParams;
		this._signingAccounts = signingAccounts;
		this._addr = algosdk.default.multisigAddress(multisigParams);
		this._signer = algosdk.default.makeMultiSigAccountTransactionSigner(multisigParams, signingAccounts.map((a) => a.sk));
	}
	/**
	* Sign the given transaction
	* @param transaction Either a transaction object or a raw, partially signed transaction
	* @returns The transaction signed by the present signers
	* @example
	* ```typescript
	* const signedTxn = multisigAccount.sign(myTransaction)
	* ```
	*/
	sign(transaction) {
		let signedTxn = "sender" in transaction ? void 0 : transaction;
		for (const signer of this._signingAccounts) if (signedTxn) signedTxn = algosdk.default.appendSignMultisigTransaction(signedTxn, this._params, signer.sk).blob;
		else signedTxn = algosdk.default.signMultisigTransaction(transaction, this._params, signer.sk).blob;
		return signedTxn;
	}
};
/** Account wrapper that supports a rekeyed account */
var SigningAccount = class {
	_account;
	_signer;
	_sender;
	/**
	* Algorand address of the sender
	*/
	get addr() {
		return this._sender;
	}
	/**
	* Secret key belonging to the signer
	*/
	get sk() {
		return this._account.sk;
	}
	/**
	* Transaction signer for the underlying signing account
	*/
	get signer() {
		return this._signer;
	}
	/**
	* Algorand account of the sender address and signer private key
	*/
	get sender() {
		return {
			addr: this._sender,
			sk: this._account.sk
		};
	}
	constructor(account, sender) {
		this._account = account;
		this._sender = typeof sender === "string" ? algosdk.Address.fromString(sender) : sender ?? account.addr;
		this._signer = algosdk.default.makeBasicAccountTransactionSigner(account);
	}
};
//#endregion
exports.DISPENSER_ACCOUNT = DISPENSER_ACCOUNT;
exports.MultisigAccount = MultisigAccount;
exports.SigningAccount = SigningAccount;

//# sourceMappingURL=account.js.map