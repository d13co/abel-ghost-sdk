import algosdk, { Address } from 'algosdk';
import { TransactionSignerAccount } from './account';
import { BoxName, type ABIReturn, type AppState, type CompiledTeal, type TealTemplateParams } from './app';
import { AtRoundOptions } from './dt-support';
import modelsv2 = algosdk.modelsv2;
/** Information about an app. */
export interface AppInformation {
    /** The ID of the app. */
    appId: bigint;
    /** The escrow address that the app operates with. */
    appAddress: Address;
    /**
     * Approval program.
     */
    approvalProgram: Uint8Array;
    /**
     * Clear state program.
     */
    clearStateProgram: Uint8Array;
    /**
     * The address that created this application. This is the address where the
     * parameters and global state for this application can be found.
     */
    creator: Address;
    /**
     * Current global state values.
     */
    globalState: AppState;
    /** The number of allocated ints in per-user local state. */
    localInts: number;
    /** The number of allocated byte slices in per-user local state. */
    localByteSlices: number;
    /** The number of allocated ints in global state. */
    globalInts: number;
    /** The number of allocated byte slices in global state. */
    globalByteSlices: number;
    /** Any extra pages that are needed for the smart contract. */
    extraProgramPages?: number;
    /** The number of updates to the application programs */
    version?: number;
}
/**
 * Something that identifies an app box name - either a:
 *  * `Uint8Array` (the actual binary of the box name)
 *  * `string` (that will be encoded to a `Uint8Array`)
 *  * `TransactionSignerAccount` (that will be encoded into the
 *    public key address of the corresponding account)
 */
export type BoxIdentifier = string | Uint8Array | TransactionSignerAccount;
/**
 * A grouping of the app ID and name identifier to reference an app box.
 */
export interface BoxReference {
    /**
     * A unique application id
     */
    appId: bigint;
    /**
     * Identifier for a box name
     */
    name: BoxIdentifier;
}
/**
 * Parameters to get and decode a box value as an ABI type.
 */
export interface BoxValueRequestParams {
    /** The ID of the app return box names for */
    appId: bigint;
    /** The name of the box to return either as a string, binary array or `BoxName` */
    boxName: BoxIdentifier;
    /** The ABI type to decode the value using */
    type: algosdk.ABIType;
    /** Read the box as of the end of this past round instead of the latest round (needs dtalgod time travel) */
    round?: number | bigint;
}
/**
 * Parameters to get and decode a box value as an ABI type.
 */
export interface BoxValuesRequestParams {
    /** The ID of the app return box names for */
    appId: bigint;
    /** The names of the boxes to return either as a string, binary array or BoxName` */
    boxNames: BoxIdentifier[];
    /** The ABI type to decode the value using */
    type: algosdk.ABIType;
    /** Read the boxes as of the end of this past round instead of the latest round (needs dtalgod time travel) */
    round?: number | bigint;
}
/**
 * Defines a holding by referring to an Address and Asset it belongs to.
 */
export type HoldingReference = {
    /** Asset ID for asset in access list. */
    assetId: bigint;
    /** Address in access list, or the sender of the transaction. */
    address: Address;
};
/**
 * Defines a local state by referring to an Address and App it belongs to.
 */
export type LocalsReference = {
    /** Application ID for app in access list, or zero if referring to the called application. */
    appId: bigint;
    /** Address in access list, or the sender of the transaction. */
    address: Address;
};
/**
 * Names a single resource reference. Only one of the fields should be set.
 */
export type ResourceReference = {
    /** Any account addresses whose balance record is accessible by the executing ApprovalProgram or ClearStateProgram. */
    address?: Address;
    /** Application ID whose GlobalState may be read by the executing ApprovalProgram or ClearStateProgram. */
    appId?: bigint;
    /** Asset ID whose AssetParams may be read by the executing ApprovalProgram or ClearStateProgram. */
    assetId?: bigint;
    /** Defines a holding by referring to an Address and Asset it belongs to. */
    holding?: HoldingReference;
    /** Defines a local state by referring to an Address and App it belongs to. */
    locals?: LocalsReference;
    /** Defines a box by its name and the application ID it belongs to. */
    box?: BoxReference;
};
/** Allows management of application information. */
export declare class AppManager {
    private _algod;
    private _compilationResults;
    /**
     * Creates an `AppManager`
     * @param algod An algod instance
     */
    constructor(algod: algosdk.Algodv2);
    /**
     * Compiles the given TEAL using algod and returns the result, including source map.
     *
     * The result of this compilation is also cached keyed by the TEAL
     *  code so it can be retrieved via `getCompilationResult`.
     *
     * This function is re-entrant; it will only compile the same code once.
     *
     * @param tealCode The TEAL code
     * @returns The information about the compiled file
     * @example
     * ```typescript
     * const compiled = await appManager.compileTeal(tealProgram)
     * ```
     */
    compileTeal(tealCode: string): Promise<CompiledTeal>;
    /**
     * Performs template substitution of a teal template and compiles it, returning the compiled result.
     *
     * Looks for `TMPL_{parameter}` for template replacements and replaces AlgoKit deploy-time control parameters
     * if deployment metadata is specified.
     *
     * * `TMPL_UPDATABLE` for updatability / immutability control
     * * `TMPL_DELETABLE` for deletability / permanence control
     *
     * @param tealTemplateCode The TEAL logic to compile
     * @param templateParams Any parameters to replace in the .teal file before compiling
     * @param deploymentMetadata The deployment metadata the app will be deployed with
     * @returns The information about the compiled code
     * @example
     * ```typescript
     * const compiled = await appManager.compileTealTemplate(tealTemplate, { TMPL_APP_ID: 12345n }, { updatable: true, deletable: false })
     * ```
     */
    compileTealTemplate(tealTemplateCode: string, templateParams?: TealTemplateParams, deploymentMetadata?: {
        updatable?: boolean;
        deletable?: boolean;
    }): Promise<CompiledTeal>;
    /**
     * Returns a previous compilation result.
     * @param tealCode The TEAL code
     * @returns The information about the previously compiled file
     *  or `undefined` if that TEAL code wasn't previously compiled
     * @example
     * ```typescript
     * const compiled = appManager.getCompilationResult(tealProgram)
     * ```
     */
    getCompilationResult(tealCode: string): CompiledTeal | undefined;
    /**
     * Returns the current app information for the app with the given ID.
     *
     * @example
     * ```typescript
     * const appInfo = await appManager.getById(12353n);
     * ```
     *
     * @param appId The ID of the app
     * @param options Optional `round` to read the app as of the end of a past round (needs dtalgod time travel)
     * @returns The app information
     */
    getById(appId: bigint, options?: AtRoundOptions): Promise<AppInformation>;
    /**
     * Converts an algod application into an `AppInformation`.
     * @param app The application from algod
     * @returns The app information
     */
    static appInformationFromAlgod(app: modelsv2.Application): AppInformation;
    /**
     * Returns the current global state values for the given app ID and account address
     *
     * @param appId The ID of the app to return global state for
     * @param options Optional `round` to read the state as of the end of a past round (needs dtalgod time travel)
     * @returns The current global state for the given app
     * @example
     * ```typescript
     * const globalState = await appManager.getGlobalState(12353n);
     * ```
     */
    getGlobalState(appId: bigint, options?: AtRoundOptions): Promise<AppState>;
    /**
     * Returns the current local state values for the given app ID and account address
     *
     * @param appId The ID of the app to return local state for
     * @param address The string address of the account to get local state for the given app
     * @param options Optional `round` to read the state as of the end of a past round (needs dtalgod time travel)
     * @returns The current local state for the given (app, account) combination
     * @example
     * ```typescript
     * const localState = await appManager.getLocalState(12353n, 'ACCOUNTADDRESS');
     * ```
     */
    getLocalState(appId: bigint, address: Address | string, options?: AtRoundOptions): Promise<AppState>;
    /**
     * Returns the names of the current boxes for the given app.
     * @param appId The ID of the app return box names for
     * @param options Optional `round` to list the boxes as of the end of a past round (needs dtalgod time travel)
     * @returns The current box names
     * @example
     * ```typescript
     * const boxNames = await appManager.getBoxNames(12353n);
     * ```
     */
    getBoxNames(appId: bigint, options?: AtRoundOptions): Promise<BoxName[]>;
    /**
     * Returns the value of the given box name for the given app.
     * @param appId The ID of the app return box names for
     * @param boxName The name of the box to return either as a string, binary array or `BoxName`
     * @param options Optional `round` to read the box as of the end of a past round (needs dtalgod time travel)
     * @returns The current box value as a byte array
     * @example
     * ```typescript
     * const boxValue = await appManager.getBoxValue(12353n, 'boxName');
     * ```
     */
    getBoxValue(appId: bigint, boxName: BoxIdentifier | BoxName, options?: AtRoundOptions): Promise<Uint8Array>;
    /**
     * Returns the value of the given box names for the given app.
     * @param appId The ID of the app return box names for
     * @param boxNames The names of the boxes to return either as a string, binary array or `BoxName`
     * @param options Optional `round` to read the boxes as of the end of a past round (needs dtalgod time travel)
     * @returns The current box values as a byte array in the same order as the passed in box names
     * @example
     * ```typescript
     * const boxValues = await appManager.getBoxValues(12353n, ['boxName1', 'boxName2']);
     * ```
     */
    getBoxValues(appId: bigint, boxNames: (BoxIdentifier | BoxName)[], options?: AtRoundOptions): Promise<Uint8Array[]>;
    /**
     * Returns the value of the given box name for the given app decoded based on the given ABI type.
     * @param request The parameters for the box value request
     * @returns The current box value as an ABI value
     * @example
     * ```typescript
     * const boxValue = await appManager.getBoxValueFromABIType({ appId: 12353n, boxName: 'boxName', type: new ABIUintType(32) });
     * ```
     */
    getBoxValueFromABIType(request: BoxValueRequestParams): Promise<algosdk.ABIValue>;
    /**
     * Returns the value of the given box names for the given app decoded based on the given ABI type.
     * @param request The parameters for the box value request
     * @returns The current box values as an ABI value in the same order as the passed in box names
     * @example
     * ```typescript
     * const boxValues = await appManager.getBoxValuesFromABIType({ appId: 12353n, boxNames: ['boxName1', 'boxName2'], type: new ABIUintType(32) });
     * ```
     */
    getBoxValuesFromABIType(request: BoxValuesRequestParams): Promise<algosdk.ABIValue[]>;
    /**
     * Returns a `algosdk.BoxReference` given a `BoxIdentifier` or `BoxReference`.
     * @param boxId The box to return a reference for
     * @returns The box reference ready to pass into a `algosdk.Transaction`
     * @example
     * ```typescript
     * const boxRef = AppManager.getBoxReference('boxName');
     * ```
     */
    static getBoxReference(boxId: BoxIdentifier | BoxReference): algosdk.BoxReference;
    /**
     * Converts an array of global/local state values from the algod api to a more friendly
     * generic object keyed by the UTF-8 value of the key.
     * @param state A `global-state`, `local-state`, `global-state-deltas` or `local-state-deltas`
     * @returns An object keyeed by the UTF-8 representation of the key with various parsings of the values
     * @example
     * ```typescript
     * const stateValues = AppManager.decodeAppState(state);
     * ```
     */
    static decodeAppState(state: {
        key: Uint8Array;
        value: modelsv2.TealValue | modelsv2.EvalDelta;
    }[]): AppState;
    /**
     * Returns any ABI return values for the given app call arguments and transaction confirmation.
     * @param confirmation The transaction confirmation from algod
     * @param method The ABI method
     * @returns The return value for the method call
     * @example
     * ```typescript
     * const returnValue = AppManager.getABIReturn(confirmation, ABIMethod.fromSignature('hello(string)void'));
     * ```
     */
    static getABIReturn(confirmation: modelsv2.PendingTransactionResponse | undefined, method: algosdk.ABIMethod | undefined): ABIReturn | undefined;
    /**
     * Replaces AlgoKit deploy-time deployment control parameters within the given TEAL template code.
     *
     * * `TMPL_UPDATABLE` for updatability / immutability control
     * * `TMPL_DELETABLE` for deletability / permanence control
     *
     * Note: If these values are defined, but the corresponding `TMPL_*` value
     *  isn't in the teal code it will throw an exception.
     *
     * @param tealTemplateCode The TEAL template code to substitute
     * @param params The deploy-time deployment control parameter value to replace
     * @returns The replaced TEAL code
     * @example
     * ```typescript
     * const tealCode = AppManager.replaceTealTemplateDeployTimeControlParams(tealTemplate, { updatable: true, deletable: false });
     * ```
     */
    static replaceTealTemplateDeployTimeControlParams(tealTemplateCode: string, params: {
        updatable?: boolean;
        deletable?: boolean;
    }): string;
    /**
     * Performs template substitution of a teal file.
     *
     * Looks for `TMPL_{parameter}` for template replacements.
     *
     * @param tealTemplateCode The TEAL template code to make parameter replacements in
     * @param templateParams Any parameters to replace in the teal code
     * @returns The TEAL code with replacements
     * @example
     * ```typescript
     * const tealCode = AppManager.replaceTealTemplateParams(tealTemplate, { TMPL_APP_ID: 12345n });
     * ```
     */
    static replaceTealTemplateParams(tealTemplateCode: string, templateParams?: TealTemplateParams): string;
    /**
     * Remove comments from TEAL code (useful to reduce code size before compilation).
     *
     * @param tealCode The TEAL logic to strip
     * @returns The TEAL without comments
     * @example
     * ```typescript
     * const stripped = AppManager.stripTealComments(tealProgram);
     * ```
     */
    static stripTealComments(tealCode: string): string;
}
