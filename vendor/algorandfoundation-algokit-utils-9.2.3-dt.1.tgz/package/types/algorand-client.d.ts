import algosdk, { Address } from 'algosdk';
import { MultisigAccount, SigningAccount, TransactionSignerAccount } from './account';
import { AccountManager } from './account-manager';
import { AlgorandClientTransactionCreator } from './algorand-client-transaction-creator';
import { AlgorandClientTransactionSender } from './algorand-client-transaction-sender';
import { AppDeployer } from './app-deployer';
import { AppManager } from './app-manager';
import { AssetManager } from './asset-manager';
import { AlgoSdkClients, ClientManager } from './client-manager';
import { ErrorTransformer, TransactionComposer } from './composer';
import { AlgoConfig } from './network-client';
import { SimulateManager } from './simulate-manager';
import { DTManager } from './dt-manager';
import Account = algosdk.Account;
import LogicSigAccount = algosdk.LogicSigAccount;
/**
 * A client that brokers easy access to Algorand functionality.
 */
export declare class AlgorandClient {
    private _clientManager;
    private _accountManager;
    private _appManager;
    private _appDeployer;
    private _assetManager;
    private _transactionSender;
    private _transactionCreator;
    private _dtManager;
    private _simulateManager;
    private _cachedSuggestedParams?;
    private _cachedSuggestedParamsExpiry?;
    private _cachedSuggestedParamsTimeout;
    private _defaultValidityWindow;
    /**
     * A set of error transformers to use when an error is caught in simulate or execute
     * `registerErrorTransformer` and `unregisterErrorTransformer` can be used to add and remove
     * error transformers from the set.
     */
    private _errorTransformers;
    private constructor();
    /**
     * Sets the default validity window for transactions.
     * @param validityWindow The number of rounds between the first and last valid rounds
     * @returns The `AlgorandClient` so method calls can be chained
     * @example
     * ```typescript
     * const algorand = AlgorandClient.mainNet().setDefaultValidityWindow(1000);
     * ```
     */
    setDefaultValidityWindow(validityWindow: number | bigint): this;
    /**
     * Sets the default signer to use if no other signer is specified.
     * @param signer The signer to use, either a `TransactionSigner` or a `TransactionSignerAccount`
     * @returns The `AlgorandClient` so method calls can be chained
     * @example
     * ```typescript
     * const signer = new SigningAccount(account, account.addr)
     * const algorand = AlgorandClient.mainNet().setDefaultSigner(signer)
     * ```
     */
    setDefaultSigner(signer: algosdk.TransactionSigner | TransactionSignerAccount): AlgorandClient;
    /**
     * Tracks the given account (object that encapsulates an address and a signer) for later signing.
     * @param account The account to register, which can be a `TransactionSignerAccount` or
     *  a `algosdk.Account`, `algosdk.LogicSigAccount`, `SigningAccount` or `MultisigAccount`
     * @example
     * ```typescript
     * const accountManager = AlgorandClient.mainNet()
     *  .setSignerFromAccount(algosdk.generateAccount())
     *  .setSignerFromAccount(new algosdk.LogicSigAccount(program, args))
     *  .setSignerFromAccount(new SigningAccount(account, sender))
     *  .setSignerFromAccount(new MultisigAccount({version: 1, threshold: 1, addrs: ["ADDRESS1...", "ADDRESS2..."]}, [account1, account2]))
     *  .setSignerFromAccount({addr: "SENDERADDRESS", signer: transactionSigner})
     * ```
     * @returns The `AlgorandClient` so method calls can be chained
     */
    setSignerFromAccount(account: TransactionSignerAccount | Account | LogicSigAccount | SigningAccount | MultisigAccount): this;
    /**
     * Tracks the given signer against the given sender for later signing.
     * @param sender The sender address to use this signer for
     * @param signer The signer to sign transactions with for the given sender
     * @returns The `AlgorandClient` so method calls can be chained
     * @example
     * ```typescript
     * const signer = new SigningAccount(account, account.addr)
     * const algorand = AlgorandClient.mainNet().setSigner(signer.addr, signer.signer)
     * ```
     */
    setSigner(sender: string | Address, signer: algosdk.TransactionSigner): this;
    /**
     * Sets a cache value to use for suggested transaction params.
     * @param suggestedParams The suggested params to use
     * @param until A date until which to cache, or if not specified then the timeout is used
     * @returns The `AlgorandClient` so method calls can be chained
     * @example
     * ```typescript
     * const algorand = AlgorandClient.mainNet().setSuggestedParamsCache(suggestedParams, new Date(+new Date() + 3_600_000))
     * ```
     */
    setSuggestedParamsCache(suggestedParams: algosdk.SuggestedParams, until?: Date): this;
    /**
     * Sets the timeout for caching suggested params.
     * @param timeout The timeout in milliseconds
     * @returns The `AlgorandClient` so method calls can be chained
     * @example
     * ```typescript
     * const algorand = AlgorandClient.mainNet().setSuggestedParamsCacheTimeout(10_000)
     * ```
     */
    setSuggestedParamsCacheTimeout(timeout: number): this;
    /**
     * Get suggested params for a transaction (either cached or from algod if the cache is stale or empty)
     * @returns The suggested transaction parameters.
     * @example
     * const params = await AlgorandClient.mainNet().getSuggestedParams();
     */
    getSuggestedParams(): Promise<algosdk.SuggestedParams>;
    /**
     * Get clients, including algosdk clients and app clients.
     * @returns The `ClientManager` instance.
     * @example
     * const clientManager = AlgorandClient.mainNet().client;
     */
    get client(): ClientManager;
    /**
     * Get or create accounts that can sign transactions.
     * @returns The `AccountManager` instance.
     * @example
     * const accountManager = AlgorandClient.mainNet().account;
     */
    get account(): AccountManager;
    /**
     * Methods for interacting with assets.
     * @returns The `AssetManager` instance.
     * @example
     * const assetManager = AlgorandClient.mainNet().asset;
     */
    get asset(): AssetManager;
    /**
     * Methods for interacting with apps.
     * @returns The `AppManager` instance.
     * @example
     * const appManager = AlgorandClient.mainNet().app;
     */
    get app(): AppManager;
    /**
     * Methods for deploying apps and managing app deployment metadata.
     * @returns The `AppDeployer` instance.
     * @example
     * const deployer = AlgorandClient.mainNet().appDeployer;
     */
    get appDeployer(): AppDeployer;
    /**
     * Time travel on dtalgod (a time-travel algod): the rounds at which boxes, apps, assets and accounts changed.
     *
     * To read state at a past round, pass `{ round }` to the usual reads, or use `appClient.atRound(round)`.
     * Needs the time-travel fork of algosdk.
     * @returns The `DTManager` instance.
     * @example
     * const { versions } = await algorand.dt.getBoxVersions(appId, 'counter', { includeValues: true });
     */
    get dt(): DTManager;
    /**
     * Extended simulate on dtalgod: several transaction groups per request, and the same groups at several rounds.
     * Needs the time-travel fork of algosdk.
     * @returns The `SimulateManager` instance.
     * @example
     * const outcomes = await algorand.simulate.rounds(composer, [45_000_000n, 45_001_000n]);
     */
    get simulate(): SimulateManager;
    /**
     * Register a function that will be used to transform an error caught when simulating or executing
     * composed transaction groups made from `newGroup`
     */
    registerErrorTransformer(transformer: ErrorTransformer): void;
    unregisterErrorTransformer(transformer: ErrorTransformer): void;
    /** Start a new `TransactionComposer` transaction group
     * @returns A new instance of `TransactionComposer`.
     * @example
     * const composer = AlgorandClient.mainNet().newGroup();
     * const result = await composer.addTransaction(payment).send()
     */
    newGroup(): TransactionComposer;
    /**
     * Methods for sending a transaction.
     * @returns The `AlgorandClientTransactionSender` instance.
     * @example
     * const result = await AlgorandClient.mainNet().send.payment({
     *  sender: "SENDERADDRESS",
     *  receiver: "RECEIVERADDRESS",
     *  amount: algo(1)
     * })
     */
    get send(): AlgorandClientTransactionSender;
    /**
     * Methods for creating a transaction.
     * @returns The `AlgorandClientTransactionCreator` instance.
     * @example
     * const payment = await AlgorandClient.mainNet().createTransaction.payment({
     *  sender: "SENDERADDRESS",
     *  receiver: "RECEIVERADDRESS",
     *  amount: algo(1)
     * })
     */
    get createTransaction(): AlgorandClientTransactionCreator;
    /**
     * Creates an `AlgorandClient` pointing at default LocalNet ports and API token.
     * @returns An instance of the `AlgorandClient`.
     * @example
     * const algorand = AlgorandClient.defaultLocalNet();
     */
    static defaultLocalNet(): AlgorandClient;
    /**
     * Creates an `AlgorandClient` pointing at TestNet using AlgoNode.
     * @returns An instance of the `AlgorandClient`.
     * @example
     * const algorand = AlgorandClient.testNet();
     */
    static testNet(): AlgorandClient;
    /**
     * Creates an `AlgorandClient` pointing at MainNet using AlgoNode.
     * @returns An instance of the `AlgorandClient`.
     * @example
     * const algorand = AlgorandClient.mainNet();
     */
    static mainNet(): AlgorandClient;
    /**
     * Creates an `AlgorandClient` pointing to the given client(s).
     * @param clients The clients to use.
     * @returns An instance of the `AlgorandClient`.
     * @example
     * const algorand = AlgorandClient.fromClients({ algod, indexer, kmd });
     */
    static fromClients(clients: AlgoSdkClients): AlgorandClient;
    /**
     * Creates an `AlgorandClient` loading the configuration from environment variables.
     *
     * Retrieve configurations from environment variables when defined or get default LocalNet configuration if they aren't defined.
     *
     * Expects to be called from a Node.js environment.
     *
     * If `process.env.ALGOD_SERVER` is defined it will use that along with optional `process.env.ALGOD_PORT` and `process.env.ALGOD_TOKEN`.
     *
     * If `process.env.INDEXER_SERVER` is defined it will use that along with optional `process.env.INDEXER_PORT` and `process.env.INDEXER_TOKEN`.
     *
     * If either aren't defined it will use the default LocalNet config.
     *
     * It will return a KMD configuration that uses `process.env.KMD_PORT` (or port 4002) if `process.env.ALGOD_SERVER` is defined,
     * otherwise it will use the default LocalNet config unless it detects testnet or mainnet.
     * @returns An instance of the `AlgorandClient`.
     * @example
     * const client = AlgorandClient.fromEnvironment();
     */
    static fromEnvironment(): AlgorandClient;
    /**
     * Creates  an `AlgorandClient` from the given config.
     * @param config The config to use.
     * @returns An instance of the `AlgorandClient`.
     * @example
     * const client = AlgorandClient.fromConfig({ algodConfig, indexerConfig, kmdConfig });
     */
    static fromConfig(config: AlgoConfig): AlgorandClient;
}
