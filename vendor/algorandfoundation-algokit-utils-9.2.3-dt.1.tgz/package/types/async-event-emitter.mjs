//#region src/types/async-event-emitter.ts
var AsyncEventEmitter = class {
	listenerWrapperMap = /* @__PURE__ */ new WeakMap();
	listenerMap = {};
	async emitAsync(eventName, event) {
		for (const listener of this.listenerMap[eventName] ?? []) await listener(event, eventName);
	}
	on(eventName, listener) {
		if (!this.listenerMap[eventName]) this.listenerMap[eventName] = [];
		this.listenerMap[eventName].push(listener);
		return this;
	}
	once(eventName, listener) {
		const wrappedListener = async (event, eventName) => {
			try {
				return await listener(event, eventName);
			} finally {
				this.removeListener(eventName, wrappedListener);
			}
		};
		this.listenerWrapperMap.set(listener, wrappedListener);
		return this.on(eventName, wrappedListener);
	}
	removeListener(eventName, listener) {
		const wrappedListener = this.listenerWrapperMap.get(listener);
		if (wrappedListener) {
			this.listenerWrapperMap.delete(listener);
			if (this.listenerMap[eventName]?.indexOf(wrappedListener) !== -1) this.listenerMap[eventName].splice(this.listenerMap[eventName].indexOf(wrappedListener), 1);
		} else if (this.listenerMap[eventName]?.indexOf(listener) !== -1) this.listenerMap[eventName].splice(this.listenerMap[eventName].indexOf(listener), 1);
		return this;
	}
	off = this.removeListener;
};
//#endregion
export { AsyncEventEmitter };

//# sourceMappingURL=async-event-emitter.mjs.map