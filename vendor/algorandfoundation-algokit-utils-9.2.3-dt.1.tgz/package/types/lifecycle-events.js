Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
//#region src/types/lifecycle-events.ts
let EventType = /* @__PURE__ */ function(EventType) {
	EventType["TxnGroupSimulated"] = "TxnGroupSimulated";
	EventType["AppCompiled"] = "AppCompiled";
	return EventType;
}({});
//#endregion
exports.EventType = EventType;

//# sourceMappingURL=lifecycle-events.js.map