import algosdk from 'algosdk';
import Algodv2 = algosdk.Algodv2;
import Kmd = algosdk.Kmd;
/**
 * @deprecated Use `algorand.account.dispenserFromEnvironment()` or `new AccountManager(clientManager).dispenserFromEnvironment()` instead
 *
 * Returns an account (with private key loaded) that can act as a dispenser
 *
 * If running on LocalNet then it will return the default dispenser account automatically,
 *  otherwise it will load the account mnemonic stored in process.env.DISPENSER_MNEMONIC
 *
 * @param algod An algod client
 * @param kmd A KMD client, if not specified then a default KMD client will be loaded from environment variables
 */
export declare function getDispenserAccount(algod: Algodv2, kmd?: Kmd): Promise<algosdk.Address & import("../types/account").TransactionSignerAccount & {
    account: import("../types/account").SigningAccount;
}>;
