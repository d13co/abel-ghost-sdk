import { ClientManager } from "../types/client-manager.mjs";
import { KmdAccountManager } from "../types/kmd-account-manager.mjs";
//#region src/localnet/get-kmd-wallet-account.ts
/**
* @deprecated use `algorand.account.kmd.getWalletAccount(name, predicate)` or `new KMDAccountManager(clientManager).getWalletAccount(name, predicate)` instead.
*
* Returns an Algorand account with private key loaded from the given KMD wallet (identified by name).
*
* @param walletAccount The details of the wallet, with:
*   * `name`: The name of the wallet to retrieve an account from
*   * `predicate`: An optional filter to use to find the account (otherwise it will return a random account from the wallet)
* @param algod An algod client
* @param kmdClient A KMD client, if not specified then a default KMD client will be loaded from environment variables
* @example Get default funded account in a LocalNet
*
* ```typescript
* const defaultDispenserAccount = await getKmdWalletAccount(algod,
*   'unencrypted-default-wallet',
*   a => a.status !== 'Offline' && a.amount > 1_000_000_000
* )
* ```
*/
async function getKmdWalletAccount(walletAccount, algod, kmdClient) {
	return (await new KmdAccountManager(new ClientManager({
		algod,
		kmd: kmdClient
	})).getWalletAccount(walletAccount.name, walletAccount.predicate))?.account;
}
//#endregion
export { getKmdWalletAccount };

//# sourceMappingURL=get-kmd-wallet-account.mjs.map