import { encodeTransactionNote, getSenderAddress } from "../transaction/transaction.mjs";
import { legacySendTransactionBridge } from "../transaction/legacy-bridge.mjs";
//#region src/transfer/transfer-algos.ts
/**
* @deprecated Use `algorand.send.payment()` / `algorand.createTransaction.payment()` instead
*
* Transfer Algo between two accounts.
* @param transfer The transfer definition
* @param algod An algod client
* @returns The transaction object and optionally the confirmation if it was sent to the chain (`skipSending` is `false` or unset)
*
* @example Usage example
* ```typescript
* await algokit.transferAlgos({ from, to, amount: algokit.algo(1) }, algod)
* ```
*/
async function transferAlgos(transfer, algod) {
	const params = {
		sender: getSenderAddress(transfer.from),
		receiver: getSenderAddress(transfer.to),
		amount: transfer.amount,
		note: encodeTransactionNote(transfer.note),
		lease: transfer.lease
	};
	return await legacySendTransactionBridge(algod, transfer.from, transfer, params, (c) => c.payment, (c) => c.payment);
}
//#endregion
export { transferAlgos };

//# sourceMappingURL=transfer-algos.mjs.map